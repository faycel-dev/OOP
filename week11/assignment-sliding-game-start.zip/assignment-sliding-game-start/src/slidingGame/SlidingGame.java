package slidingGame;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * A template of a sliding game
 */
public class SlidingGame implements Configuration {

	public static final int N = 3, SIZE = N*N, HOLE = SIZE;
	/**
	 * The board is represented by a 2-dimensional array; the position of the hole
	 * is kept in 2 variables holeX and holeY
	 */
	private int[][] board;
	private int holeX, holeY;
	private int manhattanDist = 1337;
        private Configuration predecessor;

	/**
	 * A constructor that initializes the board with the specified array
	 *
	 * @param start: a one dimensional array containing the initial board. The
	 *               elements of start are stored row-wise.
	 */
	public SlidingGame(int[] start) {
		board = new int[N][N];

		assert start.length == N * N : "Length of specified board incorrect";

		for (int p = 0; p < start.length; p++) {
			board[p % N][p / N] = start[p];
			if (start[p] == HOLE) {
				holeX = p % N;
				holeY = p / N;
			}
		}
	}

	public int getManhattanDistance() {
		return manhattanDist;
	}

	/**
	 * Converts a board into a printable representation. The hole is displayed as a
	 * space
	 *
	 * @return the string representation
	 */
	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		for (int row = 0; row < N; row++) {
			for (int col = 0; col < N; col++) {
				int puzzel = board[col][row];
				buf.append(puzzel == HOLE ? "  " : puzzel + " ");
			}
			buf.append("\n");
		}
		return buf.toString();
	}

	@Override
	public boolean equals(Object o) {
            SlidingGame s=(SlidingGame)o;
           for(int i=0;i<N;i++){
               for(int j=0;j<N;j++){
                   if(this.board[i][j]!= s.board[i][j]){
                       return false;
                   }
               }
           }
           if(this.holeX!= s.holeX || this.holeY!=s.holeY){
               return false;
           }
           return true;
        }

	@Override
	public boolean isSolution() {
          int preced=0;
          for(int i=0;i<N;i++){
              for(int j=0;j<N;j++){
                  if(board[j][i]!=++preced){
                      return false;
                  }
              }
          }
          return true;
        }

	@Override
	public Collection<Configuration> successors() {
        
             List<Configuration> st=new LinkedList<>();
             for(Direction d:Direction.values()){
                 SlidingGame succ=copySlidingGame();
                 
                 int nHoleX=holeX +d.getDX();
                 int nHoleY=holeY +d.getDY();
                 if(nHoleX <0 ||nHoleX>=N||nHoleY<0||nHoleY>=N ){
                     continue;
                 }
                 
                 int switP=succ.board[nHoleX][nHoleY];
                 succ.board[nHoleX][nHoleY]=succ.board[holeX][holeY];
                 succ.board[holeX][holeY]=switP;
                 
                 succ.holeX=nHoleX;
                 succ.holeY=nHoleY;
                 
                 succ.setManhatDist();
                 
                 succ.predecessor=this;
                 st.add(succ);
             }
             return st;
        }
private void setManhatDist(){
    this.manhattanDist=clManhattanDist();
}
	@Override
	public int compareTo(Configuration g) {
 
            
            SlidingGame s=(SlidingGame) g;
            return manhattanDist-s.getManhattanDistance();
        }

	@Override
	public Configuration getParent() {
          return predecessor;
        }

    private int clManhattanDist() {
   int sum=0;
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            if(board[i][j]==HOLE){
                continue;
            }else{
                sum+=PieceM(board[i][j],i,j);
            }
        }
    }
    return sum;
    }
    private int PieceM(int i,int x,int y){
        i--;
        int x1=i%N;
        int y1=i/N;
        return Math.abs(x-x1)+Math.abs(y-y1);
    }

    private SlidingGame copySlidingGame() {
      int[] configurat=new int[SIZE];
      int x=0;
      for(int i=0;i<N;i++){
          for(int j=0;j<N;j++){
          configurat[x++]=board[j][i];
      }
      }
      return new SlidingGame(configurat);
    }
    @Override
	public int hashCode() {
		int hash = 0;

		for(int x = N-1; x >= 0; x--){
			for(int y = N-1; y >= 0; y--){
				hash = 31 * hash + board[x][y];
			}
		}

		return hash;
	}
}


