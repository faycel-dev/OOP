package slidingGame;

import java.util.*;

/**
 * A class that implements a breadth-first search algorithm for finding the
 * Configurations for which the isSolution predicate holds
 */
public class Solver {
	// A queue for maintaining states that are not visited yet.
	private Queue<Configuration> toExamine;
	// A collection of states that have been visited
	private Collection<Configuration> encountered;
        private HashSet<Configuration> hashset;
	public Solver(Configuration g) {
            toExamine=new PriorityQueue<>();
            toExamine.add(g);
            encountered=new LinkedList<>();
            hashset = new HashSet<>();
        }

	/**
	 * A skeleton implementation of the solver
	 *
	 * @return a string representation of the solution
	 */
	public String solve() {
		while (!toExamine.isEmpty()) {
			Configuration next = toExamine.remove();
			if (next.isSolution()) {
				return solutionToString(next);
			} else {
                              hashset.add(next);
				for (Configuration succ : next.successors()) {
				 if(!hashset.contains(succ)){
                                     toExamine.add(succ);
                                 }	
                                    
				}
			}
		}
		return "Failure!";
	}
private String solutionToString (Configuration solution){
		StringBuilder out = new StringBuilder();
		int steps = 0;

		out.append("SOLUTION FOUND!\n");

		for (Configuration conf : solution.pathFromRoot()){
			out.append(String.format("Step %d\n", steps++));
			out.append(conf.toString());
			out.append("\n");
		}
                return out.toString();
}
}
