package lecture9.javafx2;

import static java.lang.Math.max;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class FXDrawRect extends Application {

   private static final double MIN_SIZE = 5;
   private static final Color[] colors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE};
   private int currentColorIx;
   private Rectangle currentRect;
   private double currentXOffset, currentYOffset;

   @Override
   public void start(Stage stage) {
      Pane pane = new Pane();
      pane.setOnMousePressed(e -> addRect(pane, e));
      pane.setOnMouseDragged(e -> dragSizeRect(e));
      pane.setOnMouseReleased(e -> finishRect(e));
      Scene scene = new Scene(pane, 400, 300);
      stage.setTitle(this.getClass().getSimpleName());
      stage.setScene(scene);
      stage.show();
   }

   private void addRect(Pane pane, MouseEvent e) {
      currentRect = new Rectangle(e.getX(), e.getY(), MIN_SIZE, MIN_SIZE);
      Color nextColor = colors[currentColorIx];
      currentRect.setFill(nextColor.deriveColor(1, 0.5, 1, 0.8));
      currentRect.setStroke(nextColor);
      currentColorIx = (currentColorIx + 1) % colors.length;
      pane.getChildren().add(currentRect);
   }

   private void dragSizeRect(MouseEvent e) {
      double newWidth = max(e.getX() - currentRect.getX(), MIN_SIZE);
      double newHeight = max(e.getY() - currentRect.getY(), MIN_SIZE);
      currentRect.setWidth(newWidth);
      currentRect.setHeight(newHeight);
   }

   private void finishRect(MouseEvent e) {
      Rectangle thisRect = currentRect;
      thisRect.setOnMousePressed(e2 -> {
         if (e2.isShiftDown()) {
            thisRect.toFront();
         }
         currentXOffset = e2.getX() - thisRect.getX();
         currentYOffset = e2.getY() - thisRect.getY();
         e2.consume(); // stop propagation up
      });
      thisRect.setOnMouseDragged(e2 -> {
         thisRect.setX(e2.getX() - currentXOffset);
         thisRect.setY(e2.getY() - currentYOffset);
         e2.consume(); // stop propagation up
      });
   }

   public static void main(String[] args) {
      launch(args);
   }

}
