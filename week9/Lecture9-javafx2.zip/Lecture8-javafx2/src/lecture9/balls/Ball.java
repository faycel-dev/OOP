package lecture9.balls;

import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @version 1.0
 */
public class Ball extends Circle {
   private final static double R = 10;
   private double x = R; 
   private double y = R; 
   private double dx;
   private double dy;
   private Random random = new Random();

   Ball() {
      super(R, R, R, Color.ORANGERED);
      dx = 1 + 3 * random.nextDouble();
      dy = 1 + 3 * random.nextDouble();
   }

   public void step(double maxX, double maxY) {
      x += dx;
      y += dy;
      if (x < R || x > maxX - R) {
         dx *= -1;
      }
      if (y < R || y > maxY - R ) {
         dy *= -1;
      }
      this.setTranslateX(x-getCenterX());
      this.setTranslateY(y-getCenterY());
   }
}
