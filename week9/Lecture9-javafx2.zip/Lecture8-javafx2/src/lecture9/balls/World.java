package lecture9.balls;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.Pane;

/**
 *
 * @version 1.0
 */
public class World extends Pane {

   private List<Ball> balls = new ArrayList<>();

   public World() {
      super();
      newBall();
   }

   public void newBall() {
      Ball ball = new Ball();
      balls.add(ball);
      this.getChildren().add(ball);
   }

   public void tick() {
      for (Ball b : balls) {
         b.step(this.getWidth(), this.getHeight());
      }
   }
}
