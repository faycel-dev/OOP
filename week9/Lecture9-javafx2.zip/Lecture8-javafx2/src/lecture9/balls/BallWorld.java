package lecture9.balls;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @version 1.0
 */
public class BallWorld extends Application {

   private final static int DELAY = 20; // timer delay in ms
   private boolean running = true;

   @Override
   public void start(Stage primaryStage) {
      World world = new World();
      Timeline timeline
              = new Timeline(new KeyFrame(Duration.millis(DELAY),
                      e -> world.tick()));
      timeline.setCycleCount(Animation.INDEFINITE);
      timeline.play();
      Scene scene = new Scene(world, 300, 250);
      scene.setOnKeyPressed(event -> {
         if (event.getCode().equals(KeyCode.N)) {
            world.newBall();
            return;
         } else {
            if (running) {
               timeline.pause();
            } else {
               timeline.play();
            }
            running = !running;
         }
      });
      primaryStage.setTitle("Bouncing balls");
      primaryStage.setScene(scene);
      primaryStage.show();
   }

   public static void main(String[] args) {
      launch(args);
   }

}
