package lecture9.timeline;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @version 1.0
 */
public class TimeLineMain extends Application {

   public void start(Stage stage) {
      final int R = 20;
      stage.setTitle(getClass().getSimpleName());
      stage.setResizable(false);
      Circle circle = new Circle(R);
      Label text = new Label();
      text.setPadding(new Insets(15));
      VBox vbox = new VBox(10);
      vbox.getChildren().addAll(circle, text);
      Scene scene = new Scene(vbox, 300, 100);
      stage.setScene(scene);
      stage.show();
      circle.setTranslateX(100);
      Timeline timeline = new Timeline();
      KeyValue kv
              = new KeyValue(circle.translateXProperty(), scene.getWidth() - 2 * R);
      KeyFrame keyFrame = new KeyFrame(Duration.seconds(4), kv);
      timeline.getKeyFrames().add(keyFrame);
      timeline.setCycleCount(10);
      timeline.setAutoReverse(true);
      timeline.currentTimeProperty().addListener((Observable ov)
              -> text.setText(String.format("%.1f s",
                      timeline.getCurrentTime().toSeconds()))
      );
      timeline.setOnFinished((ActionEvent ae) -> stage.close());
      timeline.play();
   }
   
   

   public static void main(String[] args) {
      launch(args);
   }

}
