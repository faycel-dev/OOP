package lecture9.bouncing;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class BBMain extends Application {
   final static double WIDTH = 500, HEIGHT = 400;
   @Override
   public void start(Stage stage) {
      World world = new World(WIDTH,HEIGHT);
      Ball ball = new Ball(world);
      TableView tv = new TableView(ball);
      TwoDView tdv = new TwoDView(world);

      ball.addView(tdv);
      ball.addView(tv);

      Driver driver = new Driver(ball);
      driver.start();

      Stage secondStage = new Stage();
      secondStage.setTitle("Table View");
      secondStage.setScene(new Scene(tv, 300, 200));
      secondStage.show();

      stage.setTitle("2D View");
      stage.setScene(new Scene(tdv, WIDTH, HEIGHT));
      stage.show();

   }
   public static void main(String[] args) {
      launch(args);
   }

}
