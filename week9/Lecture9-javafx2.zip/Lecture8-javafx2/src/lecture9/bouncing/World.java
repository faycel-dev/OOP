package lecture9.bouncing;

/**
 *
 * @version 1.0
 */
public class World {
   private double worldWidth, worldHeight;

   public World(double worldWidth, double worldHeight) {
      this.worldWidth = worldWidth;
      this.worldHeight = worldHeight;
   }

   public double getWorldWidth() {
      return worldWidth;
   }

   public double getWorldHeight() {
      return worldHeight;
   }

   public void setWorldWidth(double worldWidth) {
      this.worldWidth = worldWidth;
   }

   public void setWorldHeight(double worldHeight) {
      this.worldHeight = worldHeight;
   }
}
