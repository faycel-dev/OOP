package lecture9.bouncing;

import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import javafx.util.converter.NumberStringConverter;

/**
 *
 * @version 1.0
 */
public class TableView extends GridPane implements BallView {

   private Label xLabel, yLabel;
   private TextField vxLabel, vyLabel;

   public TableView( Ball b ) {
      setAlignment(Pos.CENTER);
      setHgap(5);
      setVgap(10);
      add(new Label("x"), 0, 0);
      add(xLabel = new Label(""), 1, 0);
      add(new Label("y"), 0, 1);
      add(yLabel = new Label(""), 1, 1);
      add(new Label("vx"), 0, 2);
      add(vxLabel = new TextField(String.format("%1.1f",b.getXVel())), 1, 2);
      add(new Label("vy"), 0, 3);
      add(vyLabel = new TextField(String.format("%1.1f",b.getYVel())), 1, 3);      
      vxLabel.textProperty().bindBidirectional(b.xVelProperty(), new NumberStringConverter());
      vyLabel.textProperty().bindBidirectional(b.yVelProperty(), new NumberStringConverter());
   }
  
   @Override
   public void notify(Ball ball) {
      xLabel.setText(String.format("%1.1f", ball.getXPos()));
      yLabel.setText(String.format("%1.1f", ball.getYPos()));
   }

}
