package lecture9.bouncing;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

/**
 *
 * @version 1.0
 */
public class Driver {
   private final Ball ball;

   public Driver(Ball ball) {
      this.ball = ball;
   }

   public void start() {
      Timeline loop = new Timeline(new KeyFrame(Duration.millis(20),
              e -> ball.move()));
      loop.setCycleCount(Timeline.INDEFINITE);
      loop.play();
   }
}
