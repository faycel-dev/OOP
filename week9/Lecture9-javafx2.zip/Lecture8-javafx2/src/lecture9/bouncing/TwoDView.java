package lecture9.bouncing;

import static javafx.scene.input.KeyCode.R;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;

/**
 *
 * @version 1.0
 */
public class TwoDView extends Pane implements BallView {

   private Circle ball;

   public TwoDView(World world) {
      ball = new Circle(Ball.RADIUS);
      RadialGradient rg = new RadialGradient(
              0, 0, // focusAngle, focusDistance 
              0.35, 0.25, 0.5, // centerX, centerY, radius
              true, CycleMethod.NO_CYCLE, // proportional, cycle
              new Stop(0.0, Color.WHITESMOKE), new Stop(1.0, Color.BLUE));
      ball.setFill(rg);
      getChildren().add(ball);
      widthProperty().addListener((ov, ow, nw) -> world.setWorldWidth(nw.doubleValue()));
      heightProperty().addListener((ov, ow, nw) -> world.setWorldHeight(nw.doubleValue()));
   }

   @Override
   public void notify(Ball b) {
      ball.setTranslateX(b.getXPos());
      ball.setTranslateY(b.getYPos());
   }

}
