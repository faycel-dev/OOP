package lecture9.bouncing;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

/**
 *
 * @version 1.0
 */
public class Ball {
   public final static double RADIUS = 25;
   private double xPos, yPos;
   private DoubleProperty xVel, yVel;
   private World world;   

   private List<BallView> views = new ArrayList<>();
   private Random random = new Random();
   
   public Ball( World world ) {
      this.world = world;
      xPos = RADIUS + (world.getWorldWidth()  - 2*RADIUS) * random.nextDouble();
      yPos = RADIUS + (world.getWorldHeight() - 2*RADIUS) * random.nextDouble();
      xVel = new SimpleDoubleProperty(1 + 3 * random.nextDouble());
      yVel = new SimpleDoubleProperty(1 + 3 * random.nextDouble());
   }

   public double getXPos() {
      return xPos;
   }

   public double getYPos() {
      return yPos;
   }

   public double getXVel() {
      return xVel.doubleValue();
   }

   public double getYVel() {
      return yVel.doubleValue();
   }

   public void move() {
      xPos += xVel.doubleValue();
      if ( xPos < RADIUS || xPos > world.getWorldWidth() - RADIUS) {
         xVel.set(xVel.doubleValue() * -1);
      }
      yPos += yVel.doubleValue();
      if ( yPos < RADIUS || yPos > world.getWorldHeight() - RADIUS) {
         yVel.set(yVel.doubleValue() * -1);
      }
      notifyViews();
   }

   public DoubleProperty xVelProperty() {
      return xVel;
   }

   public DoubleProperty yVelProperty() {
      return yVel;
   }
   
   public void addView( BallView view ){
      views.add(view);
   }

   private void notifyViews(){
      for( BallView view: views) {
         view.notify(this);
      }
   }
}
