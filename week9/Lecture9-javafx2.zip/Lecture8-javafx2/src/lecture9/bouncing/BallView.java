package lecture9.bouncing;

/**
 *
 * @version 1.0
 */
public interface BallView {
   void notify( Ball ball );
}
