package lecture9.analogclock;

import java.time.LocalTime;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @version 1.0
 */
public class ClockFXMain extends Application {

   protected final int R = 100, MX = R + 10, MY = R + 10;
   private Rotate hourRot, minRot, secRot;

   public void start(Stage stage) {
      Pane pane = new Pane();
      Circle circle = new Circle(MX, MY, R);
      circle.setFill(Color.WHITE);
      circle.setStroke(Color.BLACK);

      Line hourHand = new Line(MX, MY + 4, MX, MY * 0.6);
      hourHand.setStrokeWidth(6);
      hourRot = new Rotate(0, MX, MY);
      hourHand.getTransforms().add(hourRot);

      Line minHand = new Line(MX, MY + 8, MX, MY * 0.4);
      minHand.setStrokeWidth(4);
      minRot = new Rotate(0, MX, MY);
      minHand.getTransforms().add(minRot);

      Line secLine = new Line(MX, MY + 14, MX, MY * 0.2);
      secLine.setStrokeWidth(2);
      secLine.setStroke(Color.RED);
      Circle secCircle = new Circle(MX, MY - R * 0.82, 8);
      secCircle.setFill(Color.RED);
      Group secHand = new Group();
      secHand.getChildren().addAll(secLine, secCircle);
      secRot = new Rotate(0, MX, MY);
      secHand.getTransforms().add(secRot);

      pane.getChildren().addAll(circle, hourHand, minHand, secHand);
      Scene scene = new Scene(pane, 2 * R + 20, 2 * R + 20);
      scene.setFill(Color.GRAY);
      stage.setTitle("Tick tock");
      stage.setScene(scene);
      stage.show();

      Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> setTime()));
      timeline.setCycleCount(Animation.INDEFINITE);
      timeline.play();
      setTime();
   }
   
   private void setTime() {
      LocalTime now = LocalTime.now();
      hourRot.setAngle(now.getHour() * 360 / 12
              + now.getMinute() * 360 / (60 * 12));
      minRot.setAngle(now.getMinute() * 360 / 60);
      secRot.setAngle(now.getSecond() * 360 / 60);
   }

   public static void main(String[] args) {
      launch(args);
   }

}