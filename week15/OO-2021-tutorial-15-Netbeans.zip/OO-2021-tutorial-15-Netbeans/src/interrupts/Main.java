package interrupts;

import java.util.concurrent.TimeUnit;

/**
 *
 * @author dku
 */
public class Main {
    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(new Task());
        t.start();
        TimeUnit.SECONDS.sleep(3);
        t.interrupt();
    }
}
