package interrupts;

import java.util.concurrent.TimeUnit;

/**
 *
 * @author dku
 */
public class Task implements Runnable {
    public void doWork() throws InterruptedException {
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException ie) {
            throw ie;
            //Thread.currentThread().interrupt();
        }
    }
    
    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                doWork();
            }
            System.out.println("Interrupted flag is true");
        } catch (InterruptedException ie) {
            System.out.println("Caught exception from doWork");
        }
    }
}
