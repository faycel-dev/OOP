package coffeeshop;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Customer implements Callable<Double> {

    public static final int MAX_ITEMS = 10;
    private final CoffeeShop barStucks;
    private final int customerNumber;
    private final List<DrinkOrder> drinksWanted;
    private final List<Drink> drinksReceived;
    private final static Random GENERATOR = new Random();

    public Customer(int number, CoffeeShop barStucks) {
        this.barStucks = barStucks;
        customerNumber = number;
        drinksReceived = new LinkedList<>();
        drinksWanted = IntStream
                .generate(() -> GENERATOR.nextInt(DrinkOrder.values().length))
                .mapToObj(x -> DrinkOrder.values()[x])
                .limit(GENERATOR.nextInt(MAX_ITEMS) + 1)
                .collect(Collectors.toList());
    }

    private boolean isSatisfied() {
        drinksReceived.sort(null);

        return drinksReceived.equals(drinksWanted.stream()
                .map(x -> new Drink(x))
                .sorted()
                .collect(Collectors.toList())
        );
    }

    @Override
    public Double call() throws InterruptedException {
        double bill = 0.0;
        // claim a counter
        Counter counter = barStucks.claimCounter();
        try {
            // submit orders to counter
            for (DrinkOrder order : drinksWanted) {
                counter.order(order);
            }
            // collect order from counter
            while (drinksReceived.size() < drinksWanted.size()) {
                drinksReceived.add(counter.takeOrder());
            }
            // check if customer is satisfied
            if (!isSatisfied()) {
                System.err.println("Customer is not satisfied");
                System.exit(-2);
            }
            // pay bill
            bill = counter.pay();
        } finally {
            // free counter
            counter.free();
        }
        
        if (bill != drinksWanted.stream().mapToDouble(DrinkOrder::price).sum()) {
            System.err.println("The bill was messed up!");
            System.exit(-2);
        }
        return bill;
    }
}
