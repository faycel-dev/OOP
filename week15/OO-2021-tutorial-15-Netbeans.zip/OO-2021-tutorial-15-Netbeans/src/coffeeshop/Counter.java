package coffeeshop;

import java.util.concurrent.locks.ReentrantLock;

public class Counter {

    private double bill;
    private double revenue;

    private static final int BOOKSIZE = 15, TRAYSIZE = 5;
    
    private final LockingList<DrinkOrder> orderbook = new LockingList<>(BOOKSIZE);
    private final LockingList<Drink> servingTray = new LockingList<>(TRAYSIZE);
    private final ReentrantLock lock = new ReentrantLock();

    public double getRevenue() {
        // get total revenue from counter
        return revenue;
    }

    public void order(DrinkOrder order) throws InterruptedException {
        // add order to orderbook
        orderbook.add(order);
    }

    public DrinkOrder processOrder() throws InterruptedException {
        // remove order from orderbook
        DrinkOrder order = orderbook.remove();
        // add cost to bill
        bill += order.price();
        return order;
    }

    public void serveOrder(Drink drink) throws InterruptedException {
        // add drink to serving tray
        servingTray.add(drink);
    }

    public Drink takeOrder() throws InterruptedException {
        // take drink from serving tray
        return servingTray.remove();
    }

    public void claim() {
        lock.lock();
    }

    public void free() {
        lock.unlock();
    }

    public double pay() {
        // check whether the order has been completed and completely picked up
        if (!orderbook.isEmpty() || !servingTray.isEmpty()) {
            System.err.println("Order has not been completed or completely picked up yet");
            System.exit(-3);
        }
        // add bill to total revenue
        revenue += bill;
        // reset bill and return its value
        double tmp = bill;
        bill = 0;
        return tmp;
    }
}
