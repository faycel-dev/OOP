package coffeeshop;

public class Drink implements Comparable<Drink> {

    private final String type;
    
    public Drink(DrinkOrder type) {
        this.type = type.toString();
    }
    
    @Override
    public String toString() {
        return "Drink: " + this.type;
    }
    
    @Override
    public int compareTo(Drink other) {
        return this.type.compareTo(other.type);
    }
    
    @Override
    public boolean equals(Object other) {
        if (other == null || !(other instanceof Drink)) {
            return false;
        }
        return this.compareTo((Drink) other) == 0;
    }
}
