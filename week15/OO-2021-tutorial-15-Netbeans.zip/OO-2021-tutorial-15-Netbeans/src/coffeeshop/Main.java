package coffeeshop;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {

    public static final int NR_OF_CLIENTS = 10;
    public static final int NR_OF_BARISTAS = 5;

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newCachedThreadPool();
        CoffeeShop barStucks = new CoffeeShop(NR_OF_BARISTAS);

        List<Future<Double>> baristas = barStucks.open(executor);

        List<Customer> customers = IntStream.range(0, NR_OF_CLIENTS)
                .mapToObj(i -> new Customer(i, barStucks))
                .collect(Collectors.toList());
        List<Future<Double>> customerReceipts = executor.invokeAll(customers);

        double totalPaidByCustomers = computeSum(customerReceipts);

        System.out.println("All customers are done.");
        System.out.println("Total revenue: " + totalPaidByCustomers + " EUR");

        executor.shutdownNow();
        executor.awaitTermination(1, TimeUnit.HOURS);
        
        double totalFromBaristas = computeSum(baristas);
        if (totalPaidByCustomers != totalFromBaristas) {
            System.err.println("Money mismatch!");
        }
    }
    
    private static double computeSum(List<Future<Double>> futures) {
        return futures.stream()
                .mapToDouble(f -> {
                    try {
                        return f.get();
                    } catch (Exception ie) {
                         return 0.0;   
                    }
                })
                .sum();
    }
}
