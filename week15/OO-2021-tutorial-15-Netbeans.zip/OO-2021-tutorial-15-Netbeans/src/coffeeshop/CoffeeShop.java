package coffeeshop;

import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CoffeeShop {

    private final List<Counter> counters;
    private final List<Barista> baristas;
    private final static Random GENERATOR = new Random();
    
    public CoffeeShop(int nrBaristas) {
        counters = IntStream.range(0, nrBaristas)
                .mapToObj(i -> new Counter())
                .collect(Collectors.toList());

        baristas = counters.stream()
                .map(r -> new Barista(r))
                .collect(Collectors.toList());
    }

    public List<Future<Double>> open(ExecutorService executor) {
        return baristas.stream()
                .map(b -> executor.submit(b))
                .collect(Collectors.toList());
    }

    public Counter claimCounter() {
        Counter counter = counters.get(GENERATOR.nextInt(counters.size()));
        counter.claim();
        return counter;
    }

}
