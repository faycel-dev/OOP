package coffeeshop;

import java.util.concurrent.Callable;

public class Barista implements Callable<Double> {

    private final Counter counter;

    public Barista(Counter counter) {
        this.counter = counter;
    }

    private Drink create(DrinkOrder order) throws InterruptedException {
        Thread.sleep(order.creationTime());
        return new Drink(order);
    }

    @Override
    public Double call() {
        try {
            while (true) {
                // get order from counter
                DrinkOrder order = counter.processOrder();
                // create drink
                Drink drink = create(order);
                // serve order on counter
                counter.serveOrder(drink);
            }
        } catch (InterruptedException ie) {
            
        } finally {
            // return total revenue
            return counter.getRevenue();
        }
    }
}
