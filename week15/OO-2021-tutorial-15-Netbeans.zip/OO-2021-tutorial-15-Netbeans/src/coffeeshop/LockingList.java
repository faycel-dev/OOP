package coffeeshop;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class LockingList<T> {

    private final LinkedList<T> elements;
    private final int maxSize;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notFull = lock.newCondition();
    private final Condition notEmpty = lock.newCondition();

    public LockingList(int maxSize) {
        elements = new LinkedList<>();
        this.maxSize = maxSize;
    }

    public void add(T item) throws InterruptedException {
        lock.lock();
        try {
            while (elements.size() == maxSize) {
                notFull.await();
            }
            
            elements.push(item);
            notEmpty.signalAll();
        } finally {
            lock.unlock();
        }
    }

    public T remove() throws InterruptedException {
        lock.lock();
        try {
            while (elements.isEmpty()) {
                notEmpty.await();
            }
            notFull.signalAll();
            return elements.pop();
        } finally {
            lock.unlock();
        }
    }

    public boolean isEmpty() {
        lock.lock();
        try {
            return elements.isEmpty();
        } finally {
            lock.unlock();
        }
    }
}
