package coffeeshop;

public enum DrinkOrder {
    COFFEE(100, 1.50),
    TEA(50, 1.00),
    LATTE(150, 2.00),
    CAPPUCINO(150, 2.00),
    CHOCOLATE(50, 1.50);
    
    private final int creationTime;
    private final double price;
    
    DrinkOrder(int creationTime, double price) {
        this.creationTime = creationTime;
        this.price = price;
    }
    
    public int creationTime() {
        return this.creationTime;
    }
    
    public double price() {
        return this.price;
    }
}
