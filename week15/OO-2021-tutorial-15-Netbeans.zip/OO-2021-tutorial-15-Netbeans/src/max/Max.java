/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package max;

/**
 *
 * @author dku
 */
public class Max {
    public static int computeMax(int[] a, int lowerBound, int upperBound) {
        int max = Integer.MIN_VALUE;
        
        for (int i = lowerBound; i < upperBound; i += 1) {
            if (a[i] > max) {
                max = a[i];
            }
        }
        
        return max;
    }
}
