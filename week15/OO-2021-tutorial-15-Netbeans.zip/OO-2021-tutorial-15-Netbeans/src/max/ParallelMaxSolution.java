/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package max;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author dku
 */
public class ParallelMaxSolution implements Callable<Integer> {    
    private final int[] a;
    private final int lowerBound;
    private final int upperBound;
    private final int numberOfThreads;
    private static final ExecutorService exec = Executors.newCachedThreadPool();
    
    public ParallelMaxSolution(int[] a, int lowerBound, int upperBound, int numberOfThreads) {
        this.a = a;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.numberOfThreads = numberOfThreads;
    }
    
    @Override
    public Integer call() {
        if (numberOfThreads <= 1) {
            return Max.computeMax(a, lowerBound, upperBound);
        } else {
            int mid = (int) ((long) lowerBound + (long) upperBound) / 2;
            ParallelMaxSolution left = new ParallelMaxSolution(a, lowerBound, mid, numberOfThreads / 2);
            ParallelMaxSolution right = new ParallelMaxSolution(a, mid, upperBound, numberOfThreads / 2);
            Future<Integer> leftSolution = exec.submit(left);
            Future<Integer> rightSolution = exec.submit(right);
            
            try {
                return Math.max(leftSolution.get(), rightSolution.get());
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                return Integer.MIN_VALUE;
            }
        }
    }
    
    public static int computeMax(int[] a) {
        ParallelMaxSolution task = new ParallelMaxSolution(a, 0, a.length, 4);
        Future<Integer> max = exec.submit(task);
        
        try {
            return max.get();
        } catch (InterruptedException ex) {
            return Integer.MIN_VALUE;
        } catch (ExecutionException ex) {
            Logger.getLogger(ParallelMaxSolution.class.getName()).log(Level.SEVERE, null, ex);
            return Integer.MIN_VALUE;
        } finally {
            exec.shutdown();
        }
    }
}
