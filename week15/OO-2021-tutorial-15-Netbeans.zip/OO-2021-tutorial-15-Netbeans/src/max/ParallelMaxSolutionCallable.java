/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package max;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 *
 * @author dku
 */
public class ParallelMaxSolutionCallable implements Callable<Integer> {

    private final int[] a;
    private final int lowerBound;
    private final int upperBound;
    private final int numberOfThreads;
    private static final ExecutorService exec = Executors.newCachedThreadPool();

    /**
     *
     * @param a
     * @param lowerBound
     * @param upperBound
     * @param numberOfThreads
     */
    public ParallelMaxSolutionCallable(int[] a, int lowerBound, int upperBound, int numberOfThreads) {
        this.a = a;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.numberOfThreads = numberOfThreads;
    }

    @Override
    public Integer call() {
        if (numberOfThreads <= 1) {
            return Max.computeMax(a, lowerBound, upperBound);
        } else {
            int mid = (int) ((long) lowerBound + (long) upperBound) / 2;
            Callable<Integer> left = new ParallelMaxSolutionCallable(a, lowerBound, mid, numberOfThreads / 2);
            Callable<Integer> right = new ParallelMaxSolutionCallable(a, mid, upperBound, numberOfThreads / 2);
            Future<Integer> leftResult = exec.submit(left);
            Future<Integer> rightResult = exec.submit(right);
            
            try {
                return Math.max(leftResult.get(), rightResult.get());
            } catch (Exception e) {
                return Integer.MIN_VALUE;
            }
        }
    }

    /**
     *
     * @param a
     * @return
     */
    public static int computeMax(int[] a) {
        ParallelMaxSolutionCallable task = new ParallelMaxSolutionCallable(a, 0, a.length, 4);
        Future<Integer> result = exec.submit(task);

        try {
            return result.get();
        } catch (InterruptedException | ExecutionException ex) {
            return Integer.MIN_VALUE;
        } finally {
            exec.shutdown();
        }
    }
}
