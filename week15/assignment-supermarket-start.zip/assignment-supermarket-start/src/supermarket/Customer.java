package supermarket;

import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;

public class Customer implements Callable<Integer> {

	public static final int MAX_ITEMS = 20;
	private final Store store;
	private final int customerNumber;
	private final int numberOfItemsWanted;
	private final static Random GENERATOR = new Random();
	
	public int getNumberOfItemsWanted() {
		return numberOfItemsWanted;
	}

	public Customer(int number, Store store) {
		this.store = store;
		customerNumber = number;
		numberOfItemsWanted = GENERATOR.nextInt(MAX_ITEMS) + 1;
	}

	@Override
	public Integer call() throws InterruptedException{
		int numberOfItemsBought = 0;
                List<Item> clientItems=store.getItems(numberOfItemsBought);
                clientItems.add(null);
                Register register=store.claimRegister(GENERATOR.nextInt(store.NUMBER_OF_CHECKOUTS));
                register.claim();
                for(Item item:clientItems){
                    register.putOnBelt(item);
                }
                boolean finished =false;
              while(!finished){
                    Item current = register.removeFromBelt();
                    numberOfItemsBought++;
                    if(current==null){
                        finished=true;
                    }
                }
                register.free();
		return numberOfItemsBought;
	}
}
