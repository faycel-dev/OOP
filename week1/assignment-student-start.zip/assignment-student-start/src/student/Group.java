package student;

public class Group {
    private Student[] students;
    private int size=0;
    private int current=0;
    public Group(int j){
        this.size=j;
        this.students=new Student[size];
    }

    public Student[] getStudents() {
        return this.students;
    }
    public void addStudent(String name,String fname,int snumber){
        this.students[current++]= new Student(name,fname,snumber);
    }
    public void alterStudent(String name,String fname,int snumber){
        for(Student s : this.students){
            if(s.getSnumber()==snumber){
                s.newname(name,fname);
            }
        }

    }
    @Override
    public String toString() {
        String out="";
        for(Student s :this.students){
            out += s.toString() + "\n";
        }
        return out;
    }
}
