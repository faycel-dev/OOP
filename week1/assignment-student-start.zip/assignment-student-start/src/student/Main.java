package student;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    	Scanner scanner=new Scanner(System.in);
    	System.out.println("\nPlease enter the group size:");
     int n =scanner.nextInt();
     Group group=new Group(n);

     for(Student s:group.getStudents()){
     	System.out.println("Please enter a student: ");
		 int snumber=scanner.nextInt();
     	String name=scanner.next();
     	String fname=scanner.next();
     	group.addStudent(name,fname,snumber);
	 }



       System.out.println("\nthe group contains: ");
		System.out.println(group.toString());

		System.out.println("Student number and new given/family name?");
		int i=scanner.nextInt();
		while(i>0){
			String name=scanner.next();
			String fname=scanner.next();
			group.alterStudent(name,fname,i);
			System.out.println("\nthe group contains: ");
			System.out.println(group.toString());
			i=scanner.nextInt();
			scanner.nextLine();
		}
		System.out.println("Bye!");
		scanner.close();
    }

}
