package student;

public class Student {
    private String name;
    private String fname;
    private int snumber;
    public Student(String name,String fname,int snumber){
        this.fname=fname;
        this.name=name;
        this.snumber=snumber;
    }
  public void newname(String name,String fname)
  {
      this.name=name;
      this.fname=fname;
  }

    public int getSnumber() {
        return snumber;
    }

    @Override
    public String toString() {
        return name + " " + fname + ", s"+snumber;
    }
}
