package student;

public class Assignment01Tester {

	public void createGroup(int i) {
	}

	public void addStudent(int sNumber, String firstName, String lastName) {
	}

	public void changeStudent(int sNumber, String firstName, String lastName) {
	}

	public String printStudents() {
		return "";
	}

}
