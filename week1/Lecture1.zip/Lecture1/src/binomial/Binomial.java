package binomial;

/**
 *
 * @author Sjaak Smetsers
 * @version 1.0
 */
public class Binomial {

    public static void main(String[] args) {
        PascalsTriangle pt = new PascalsTriangle(20);        
        System.out.println(pt.choose(7, 3));
    }
    
    private static int choose (int n, int k) {
        if (k == 0 || k == n) {
            return 1;
        } else {
            return choose(n-1,k-1) + choose(n-1,k);
        }
    }
}
