package binomial;

/**
 *
 * @author Sjaak
 */
public class PascalsTriangle
{
    private int binomial [][];
    
    public PascalsTriangle (int N) {
        binomial = new int [N+1][];
        for (int n = 0; n <= N; n++) {
            binomial[n] = new int [n+1];
            binomial[n][0] = binomial[n][n] = 1;
            for (int k = 1; k < n; k++) {
                binomial[n][k] = binomial[n-1][k-1] + binomial[n-1][k];
            }
        }
    }
    
    public int choose (int n, int k) {
        return binomial[n][k]; 
    }
}
