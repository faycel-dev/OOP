package primes;

/**
 *
 * @author Sjaak
 * week 1 --- 31-1-2017
 */
class PrimeGenerator
{
    private int nextPrime;

    public PrimeGenerator () {
      nextPrime = 2;
    }

    public int next () {
      int this_prime = nextPrime;
      findNextPrime ();
      return this_prime;
    }     

        
    private boolean isPrime    () {
      if (nextPrime % 2 == 0) {
        return false;
      } else {
        for (int i=3; i * i <= nextPrime; i+=2) {
          if (nextPrime % i == 0) {
            return false;
          }
        }
        return true;
      }
    } 
    private void findNextPrime () {
          do {
             nextPrime++;
          } while (! isPrime ());
    }
  
}
