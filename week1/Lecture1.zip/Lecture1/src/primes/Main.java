package primes;

/**
 *
 * @author Sjaak Smetsers
 * week 1 --- 04-02-2020
 */
public class Main {
    public static void main(String[] args) {
        new PrimeIO().generatePrimes();
    }
}
