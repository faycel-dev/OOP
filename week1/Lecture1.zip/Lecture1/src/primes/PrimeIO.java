package primes;

import java.util.Scanner;

/**
 *
 * @author Sjaak Smetsers <s.smetsers@cs.ru.nl>
 */
public class PrimeIO {

    Scanner myScanner = new Scanner(System.in);

    public void generatePrimes() {
        System.out.print("How many prime numbers? ");
        int n = myScanner.nextInt();

        PrimeGenerator pg = new PrimeGenerator();

        for (int i = 0; i < n; i++) {
            System.out.print(pg.next() + " ");
        }
    }
}
