/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

/**
 *
 * @author fayce
 */
public class Constant implements Formula{
    private boolean constant;
    
    public Constant(boolean a){
        this.constant=a;
    }

    public boolean getConstant(){
        return constant;
    }
    @Override
    public <R, A> R accept(FormulaVisitor<R, A> v, A a) {
     return v.visit(this, a);
    }

    @Override
    public int getPrecedence() {
      return 0;
    }
    
}
