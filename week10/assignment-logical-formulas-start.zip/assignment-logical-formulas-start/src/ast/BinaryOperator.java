/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

/**
 *
 * @author fayce
 */
public class BinaryOperator implements Formula{

    private Formula leftOperand;
    private Formula rightOperand;
    private BinOp operaotr;
    
    
public BinaryOperator(BinOp operaotr,Formula leftOperand, Formula rightOperand){
    this.operaotr=operaotr;
    this.leftOperand=leftOperand;
    this.rightOperand=rightOperand;
    
}
public BinOp getOperator(){
    return operaotr;
}
public Formula getRightOperand(){
    return rightOperand;
}
public Formula getLeftOperand(){
    return leftOperand;
}
    @Override
    public <R, A> R accept(FormulaVisitor<R, A> v, A a) {
          return v.visit(this,a);
    }

    @Override
    public int getPrecedence() {
        return operaotr.precedence;
    }
    
}
