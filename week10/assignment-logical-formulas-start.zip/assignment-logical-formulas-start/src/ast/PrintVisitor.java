/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

/**
 *
 * @author fayce
 */
public class PrintVisitor implements FormulaVisitor<Void,Integer>{
    
    private StringBuilder result;

  
public PrintVisitor(){
    result =new StringBuilder();
}

@Override
 public String toString() {
    return result.toString();
    }
@Override
 public Void visit(Not formula, Integer a) {
   result.append("!");
   formula.getOperand().accept(this, formula.getPrecedence());
   return null;
    }

    @Override
    public Void visit(BinaryOperator formula, Integer a) {
      if(formula.getPrecedence()<=a){
          result.append("(");
      }
      formula.getLeftOperand().accept(this, formula.getPrecedence());
      result.append(formula.getOperator().toString());
      formula.getRightOperand().accept(this,formula.getPrecedence());
     
      if(formula.getPrecedence()<=a){
          result.append(")");
      }
      return null;
    }

    @Override
    public Void visit(Atom formula, Integer a) {
      result.append(formula.getAtom());
      return null;
    }

    @Override
    public Void visit(Constant formula, Integer a) {
       if(formula.getConstant()){
           result.append("true");
       }else{
           result.append("false");
       }
       return null;
    }
    
    
  
    
  }
