/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;

import java.util.Map;

/**
 *
 * @author fayce
 */
public class EvaluateVisitor implements FormulaVisitor<Boolean,Void>{

    private Map<String,Boolean> env;
    
    
public EvaluateVisitor(Map<String,Boolean>env){
    this.env=env;
 }
 @Override
public Boolean visit(Not formula, Void a) {
    return !formula.getOperand().accept(this,null);
 }
 @Override
public Boolean visit(BinaryOperator formula, Void a) {
 return formula.getOperator().apply(formula.getLeftOperand().accept(this,null),formula.getRightOperand().accept(this,null));
 }

@Override
public Boolean visit(Atom formula, Void a) {
 return env.get(formula.getAtom());
  }

    
    @Override
    public Boolean visit(Constant formula, Void a) {
        return formula.getConstant();
    }
    
    
}
