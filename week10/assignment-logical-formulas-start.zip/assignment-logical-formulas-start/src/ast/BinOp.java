/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ast;
import java.util.function.BinaryOperator;
/**
 *
 * @author fayce
 */
public enum BinOp implements BinaryOperator<Boolean>{
   AndOp("/\\", (a1, a2) -> a1 && a2,3),
    OrOp("\\/", (a1, a2) -> a1 || a2,2),
    ImpliesOp("=>", (a1, a2) -> !a1 || a2,1);
    
    
public final String string;
public final BinaryOperator<Boolean> operator;
public final int precedence;

BinOp(String string,BinaryOperator<Boolean> operator,int precedence){
    this.string=string;
    this.operator=operator;
    this.precedence=precedence;
}
    @Override
    public Boolean apply(Boolean a1, Boolean a2) {
       return operator.apply(a1,a2);
    }
    
    
    
}
