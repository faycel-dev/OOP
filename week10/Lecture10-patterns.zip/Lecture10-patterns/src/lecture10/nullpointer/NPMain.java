package lecture10.nullpointer;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class NPMain {

   public static void main(String[] args) {
      new NPMain().run();
   }

   public static <E extends Comparable<E>> E max0(Collection<E> c) {
      E currentMax = null;
      for (E e : c) {
         if (currentMax == null || e.compareTo(currentMax) > 0) {
            currentMax = e;
         }
      }
      return currentMax;
   }
   
   private List<String> list0 = Arrays.asList("Allice", "Carol", "Bob");
   private List<String> list1 = Arrays.asList();
   
   public void run() {
      String m00 = max0(list0);
      String m01 = max0(list1);
      System.out.println("m00 = " + m00 + " m01 = " + m01);
   }

}
