package lecture10.patterns;

/**
 *
 * @version 1.0
 */
public class Lecture10Patterns {

    public static void main(String[] args) {
        // TODO code application logic here
    }

}
