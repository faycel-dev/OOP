package lecture10.singleton;

/**
 *
 * @version 1.0
 */
public class SingleMain {

    public static void main(String[] args) {
//       Singleton single = new Singleton();
    }

}
