package lecture10.singleton;

/**
 *
 * @version 1.0
 */
public class ExtendedSingleton { // extends Singleton {
   public ExtendedSingleton() {      
   }
}
