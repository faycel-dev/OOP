package lecture10.singleton;

/**
 *
 * @version 1.0
 */
public class Singleton {
   private Singleton () {
   }
}
