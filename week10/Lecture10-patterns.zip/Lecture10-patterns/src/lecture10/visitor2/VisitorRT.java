package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public interface VisitorRT<R,T> {
   R visit( Book book, T arg );
   R visit( DVD dvd, T arg );
   R visit( GiftBox box, T arg );
   R visit( ShoppingCart cart, T arg );
}
