package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public interface VisitableRT {
   <R,T> R accept( VisitorRT<R,T> v, T arg);
}
