package lecture10.visitor2;

import lecture10.visitor.*;

/**
 *
 * @version 1.0
 */
public interface Visitor {
   void visit( Book book );
   void visit( DVD dvd );
   void visit( GiftBox box );
   void visit( ShoppingCart cart );
}

