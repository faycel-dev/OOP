package lecture10.visitor2;

import java.util.Arrays;
import java.util.List;

public class GiftBox extends Item {

   private final List<Item> items;

   public GiftBox(String name, Item ... items) {
      super(name, getTotalPrice(items));
      this.items = Arrays.asList(items);
   }

   private static double getTotalPrice( Item[] items ){
      double sum = 0;
      for ( Item item: items ){
         sum += item.getPrice();
      }
      return sum;
   }
   
   @Override
   public void accept(Visitor v) {
      v.visit(this);
   }

   @Override
   public <R, T> R accept(VisitorRT<R, T> v, T arg) {
      return v.visit(this, arg);
   }

   public List<Item> getItems() {
      return items;
   }
}
