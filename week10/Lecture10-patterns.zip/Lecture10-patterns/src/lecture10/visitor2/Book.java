package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public class Book extends Item {

   private final double weight;
   private final String author;

   public Book(double w, String a, String t, double p) {
      super(t, p);
      this.weight = w;
      this.author = a;
   }

   @Override
   public void accept(Visitor v) {
      v.visit(this);
   }

   @Override
   public <R, T> R accept(VisitorRT<R, T> v, T arg) {
      return v.visit(this, arg);
   }

   @Override
   public String toString() {
      return String.format("Book: %s %s", author, super.toString());
   }

   public double getWeight() {
      return weight;
   }

   public String getAuthor() {
      return author;
   }


}
