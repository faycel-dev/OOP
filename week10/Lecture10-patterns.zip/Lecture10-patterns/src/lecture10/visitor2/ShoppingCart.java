package lecture10.visitor2;

import java.util.LinkedList;
import java.util.List;

public class ShoppingCart implements Visitable, VisitableRT {

   private List<Item> items;

   @Override
   public void accept(Visitor v) {
      v.visit(this);
   }

   @Override
   public <R, T> R accept(VisitorRT<R, T> v, T arg) {
      return v.visit(this, arg);
   }

   public ShoppingCart() {
      items = new LinkedList<>();
   }

   public void add(Item item) {
      items.add(item);
   }

   public List<Item> getItems() {
      return items;
   }

   @Override
   public String toString() {
      StringBuilder out = new StringBuilder();
      items.forEach(item -> out.append(item).append("\n"));
      return out.toString();
   }
}
