package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public class DVD extends Item {

   private final double duration;
   private final int discs;

   public DVD(double d, int c, String n, double p) {
      super(n, p);
      this.duration = d;
      this.discs = c;
   }

   @Override
   public void accept(Visitor v) {
      v.visit(this);
   }

   @Override
   public <R, T> R accept(VisitorRT<R, T> v, T arg) {
      return v.visit(this, arg);
   }

   public String toString() {
      return String.format("DVD: %s, %d discs", super.toString(), discs);
   }

   public double getDuration() {
      return duration;
   }

   public int getDiscs() {
      return discs;
   }
}
