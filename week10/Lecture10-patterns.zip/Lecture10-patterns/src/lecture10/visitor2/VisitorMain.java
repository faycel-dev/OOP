package lecture10.visitor2;

public class VisitorMain {

   public static void main(String[] args) {
      run2();
   }

   private static void run() {
      ShoppingCart cart = new ShoppingCart();
      cart.add(new Book(0.8, "Douglas Hofstadter", "Godel, Escher, Bach", 17.99));
      cart.add(new Book(0.1, "J. K. Rowling", "Sorcerer's Stone", 12.35));
      cart.add(new DVD(2.28, 1, "Spectre", 14.99));
      cart.add(new GiftBox("Hitchhiker's Guide",
              new Book(0.5, "Adams", "The Hitchhiker's Guide to the Galaxy", 14.99),
              new Book(0.5, "Adams", "The Restaurant at the End of the Universe", 14.99)));

      System.out.println(cart);
      CountVisitor count = new CountVisitor();
      cart.accept(count);
      System.out.println(count);
   }
   private static void run2() {
      ShoppingCart cart = new ShoppingCart();
      cart.add(new Book(0.8, "Douglas Hofstadter", "Godel, Escher, Bach", 17.99));
      cart.add(new Book(0.1, "J. K. Rowling", "Sorcerer's Stone", 12.35));
      cart.add(new DVD(2.28, 1, "Spectre", 14.99));

      WeightVisitor wv = new WeightVisitor();
      cart.accept(wv);
      System.out.println(wv);
      
      StringReprVisitor srv = new StringReprVisitor();
      StringBuilder sb = new StringBuilder();
      cart.accept(srv, sb);
      System.out.println(sb);
   }
}
