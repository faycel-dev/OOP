package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public class WeightVisitor implements Visitor {

   private double totalWeight = 0.0;

   @Override
   public void visit(Book book) {
      totalWeight += book.getWeight();
   }

   @Override
   public void visit(DVD dvd) {
      totalWeight += 0.05 + dvd.getDiscs() * 0.026;
   }

   @Override
   public void visit(GiftBox box) {
      totalWeight += 0.1;
      box.getItems().forEach( item -> item.accept(this));
   }

   @Override
   public void visit(ShoppingCart cart) {
      cart.getItems().forEach( item -> item.accept(this));
   }

   public double getTotalWeight() {
      return totalWeight;
   }

   public String toString() {
      return "Total weight = " + totalWeight + "Kg";
   }

}
