package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public interface Visitable {
    void accept(Visitor visitor);    
}


