package lecture10.visitor2;

/**
 *
 * @version 1.0
 */
public class StringReprVisitor implements VisitorRT<Void, StringBuilder>{

   @Override
   public Void visit(Book book, StringBuilder sb) {
      sb.append(book);
      return null;
   }

   @Override
   public Void visit(DVD dvd, StringBuilder sb) {
     sb.append(dvd);
     return null;
   }

   @Override
   public Void visit(GiftBox box, StringBuilder sb) {
      sb.append("Gift box: ");
      box.getItems().forEach( item -> item.accept(this, sb));
      return null;
   }

   @Override
   public Void visit(ShoppingCart cart, StringBuilder sb) {
      cart.getItems().forEach( item -> item.accept(this, sb));
      return null;
  }

}
