package lecture10.visitor;

/**
 *
 * @version 1.0
 */
public interface Visitable {
    void accept(Visitor visitor);    
}


