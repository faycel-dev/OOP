package lecture10.visitor;

import java.util.Arrays;

public class VisitorMain {

   public static void main(String[] args) {
      run();
   }

   private static void run() {
      ShoppingCart cart = new ShoppingCart();
      cart.add(new Book(0.8, "Douglas Hofstadter", "Godel, Escher, Bach", 17.99));
      cart.add(new Book(0.1, "J. K. Rowling", "Sorcerer's Stone", 12.35));
      cart.add(new DVD(2.28, 1, "Spectre", 14.99));
      cart.add(new GiftBox("Hitchhiker's Guide",
              new Book(0.5, "Adams", "The Hitchhiker's Guide to the Galaxy", 14.99),
              new Book(0.5, "Adams", "The Restaurant at the End of the Universe", 14.99)));

      System.out.println(cart);
      CountVisitor count = new CountVisitor();
      cart.accept(count);
      System.out.println(count);

   }
}
