package lecture10.visitor;

public class CountVisitor implements Visitor {
   private int books = 0;
   private int dvds = 0;

   @Override
   public void visitBook(Book book) {
      books += 1;
   }

   @Override
   public void visitDVD(DVD dvd) {
      dvds += 1;
   }

   @Override
   public void visitGiftBox(GiftBox box) {
      for (Item item : box.getItems()) {
         item.accept(this); 
      };
   }

   @Override
   public void visitShoppingCart(ShoppingCart cart) {
      cart.getItems().forEach( item -> item.accept(this) );
   }

   public int getBooks() {
      return books;
   }

   public int getDVDs() {
      return dvds;
   }

   public String toString() {
      return "books = " + books + ", dvds = " + dvds;
   }

}
