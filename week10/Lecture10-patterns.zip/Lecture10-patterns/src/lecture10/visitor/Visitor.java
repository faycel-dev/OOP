package lecture10.visitor;

/**
 *
 * @version 1.0
 */
public interface Visitor {
   void visitBook( Book book );
   void visitDVD( DVD dvd );
   void visitGiftBox( GiftBox box );
   void visitShoppingCart( ShoppingCart cart );
}

