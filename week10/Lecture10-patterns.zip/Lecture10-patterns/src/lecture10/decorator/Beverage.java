package lecture10.decorator;

/**
 *
 * @version 1.0
 */
public abstract class Beverage {
  @Override
  public abstract String toString();

  public abstract double cost();
}
