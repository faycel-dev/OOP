package lecture10.decorator;

/**
 *
 * @version 1.0
 */
public class Milk extends BeverageDecorator {

   public Milk(Beverage beverage) {
      super(beverage);
   }

   @Override
   public String toString() {
      return beverage.toString() + ", milk";
   }

   @Override
   public double cost() {
      return super.cost() + 0.15;
   }
}
