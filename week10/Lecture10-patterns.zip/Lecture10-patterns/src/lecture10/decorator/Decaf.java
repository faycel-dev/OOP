package lecture10.decorator;

/**
 *
 * @version 1.0
 */
public class Decaf extends Beverage {

   @Override
   public String toString() {
      return "Decaf";
   }

   @Override
   public double cost() {
      return 1.50;
   }
}
