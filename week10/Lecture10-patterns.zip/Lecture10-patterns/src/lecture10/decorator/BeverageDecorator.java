package lecture10.decorator;

/**
 *
 * @version 1.0
 */
public abstract class BeverageDecorator extends Beverage {

   protected final Beverage beverage;

   public BeverageDecorator(Beverage beverage) {
      this.beverage = beverage;
   }

   @Override
   public double cost() {
      return beverage.cost();
   }

}
