package lecture10.decorator;

public class Sugar extends BeverageDecorator {

   public Sugar(Beverage beverage) {
      super(beverage);
   }

   @Override
   public String toString() {
      return beverage.toString() + ", sugar";
   }
}
