package quiz;





public class Main {

	public static void main(String[] args) {
	 Control tryit=new Control();
         tryit.play();
         
		
	}

}