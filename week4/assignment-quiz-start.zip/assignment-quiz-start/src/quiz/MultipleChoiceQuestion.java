/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 *
 * @author fayce
 */
public class MultipleChoiceQuestion extends Question {
    private int correctAnswer;
    private String[] answers; 
    
    public MultipleChoiceQuestion(String question,String[] answers,int correctAnswer,int score){
      super(question,score);
      this.correctAnswer=correctAnswer;
      this.answers=answers;
    }
    public MultipleChoiceQuestion(String question,String[] answers,int correctAnswer){
      super(question);
      this.correctAnswer=correctAnswer;
      this.answers=answers;
    }
    public String[] getAnswers(){
        return answers;
    }
    public int getCorrectAnswer(){
        return correctAnswer;
    }
     @Override
    public boolean isCorrect(String answer) {
     if(answer.charAt(0)-97<answers.length)  {
         return answers[correctAnswer].equalsIgnoreCase(answers[answer.charAt(0)-97]);
     } else{
         throw new ArrayIndexOutOfBoundsException(" pick one answer!\n");
     }
    }

    @Override
    public String correctAnswer() {
        return String.format("%c", correctAnswer + 97);
    }

    @Override
    public String toString() {
       StringBuilder out=new StringBuilder(String.format("%s\n", super.getQuestion()));
    int i=97;
    for(String s :answers){
        out.append(String.format("%c) %s\n", i++,s));
    }
    return out.toString();
    }
    
}
