/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

import java.util.Scanner;

/**
 *
 * @author fayce
 */
public class GameUI {
   private Scanner scan=new Scanner(System.in); 
   
   public void showQuestion(String question){
       System.out.println(String.format("%s\n",question));
   }
   public String getAnswer() throws Exception{
       String in=scan.nextLine().toLowerCase();
       if(in.length()>0){
           return in;
       }else{
           throw new Exception("no answer has been entered ");
       }
   }
}
