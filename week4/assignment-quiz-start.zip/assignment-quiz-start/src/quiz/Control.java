/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 *
 * @author fayce
 */
public class Control {
    private Game model;
    private GameUI view;
    public Control(){
        model=new Game();
        view=new GameUI();
    }
    public void play(){
        model.sampleQuestions();
        for(Question question : model.getQuestions()){
            view.showQuestion(question.toString());
            boolean trueans=false;
            while(!trueans){
                try{
                    if(model.trueAnswer(question, view.getAnswer())){
                        model.newScore(1, question.getScore());
                    }else{
                        model.getMistakes().add(question);
                    }
                    trueans=true;
                }catch(Exception e){
                    System.out.println("something went wrong");
                }
            }
        }
        
        for(Question question :model.getMistakes()){
            view.showQuestion(question.toString());
            boolean trueans=false;
            while(!trueans){
                try{
                    if(model.trueAnswer(question, view.getAnswer())){
                        model.newScore(2, question.getScore());
                    }
                }catch(Exception e){
                    System.out.println("something went wrong");
                }
                trueans=true;
            }
        }
        
        System.out.println(String.format("you got %d out of %d point(s) in round 1 ", model.getScore(1),model.finalScore()));
        System.out.println(String.format("you got %d out of %d point(s) in round 2 ", model.getScore(2),model.finalScore()-model.getScore(1)));
         
   
    }
}
