/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;

/**
 *
 * @author fayce
 */
public abstract class Question {
    private String question;
    private int score;
    public String getQuestion(){
        return question;
    }
    public int getScore(){
        return score;
    }
    public Question(String question){
        this.question=question;
        this.score=3;
    }
    public Question(String question,int score){
        this.question=question;
        if(score > 0 && score < 6){
            this.score=score;
        }else{
            this.score=3;
        }
    }
    
    public abstract boolean isCorrect(String answer);
    public abstract String correctAnswer();
  
    public abstract String toString();
}
