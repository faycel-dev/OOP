package cardenum;

import java.util.Random;

public class DeckOfCards {

    private Card deck[];
    private int currentCard;  // number of cards

    public final int DECK_SIZE = 52;

    // set up deck of Cards
    public DeckOfCards() {
        deck = new Card[DECK_SIZE];
        currentCard = 0;

        for (Card.Suit suit : Card.Suit.values()) {
            for (Card.Face face : Card.Face.values()) {
                deck[currentCard++] = new Card(face, suit);
            }
        }
    }

    // output deck
    public void printCards() {
        // display 52 cards in 4 columns
        int col_nr = 0;
        for (Card card : deck) {
            System.out.printf("%-5s", card);
            if (col_nr == 3) {
                System.out.println();
                col_nr = 0;
            } else {
                col_nr++;
            }
        }
    }

    public void shuffle() {
        Random ran = new Random();

        for (int i = 0; i < DECK_SIZE; i++) {
            int next = ran.nextInt(DECK_SIZE);
            Card tmp = deck[next];
            deck[next] = deck[i];
            deck[i] = tmp;
        }

    }

    public static void main(String args[]) {
        DeckOfCards cards = new DeckOfCards();
        cards.shuffle();
        cards.printCards();
    }
}
