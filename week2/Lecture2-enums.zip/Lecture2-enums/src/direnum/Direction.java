
package direnum;

/**
 *
 * @author Sjaak
 */
public enum Direction {
    N, E, S, W;

    public Direction turnLeft() {
        switch (this) {
            case N:  return W;
            case E:  return N;
            case S:  return E;
            default: return S;
        }
    }
}
