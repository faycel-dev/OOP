/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package references;

/**
 *
 * @author Sjaak
 */
public class Clock {

    private int hou, min;

    public Clock( int hou, int min ) {
        setTime( hou, min );
    }

    public void setTime( int hou, int min ) {
        this.hou = hou;
        this.min = min;
    }

    public String toString() {
        return String.format( "%2d:%2d", hou, min );
    }
};

