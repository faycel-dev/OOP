package iconTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Sjaak
 */
public class IconTester {

    public static void main(String[] args) {
        helloMars2();
    }

    static void helloWorld() {
        JOptionPane.showMessageDialog(
            null,
            "Hello, World!");
    }

    static void helloWorld2() {
        JOptionPane.showMessageDialog(
            null,
            "Hello, World!",
            "Greeting",
            JOptionPane.INFORMATION_MESSAGE,
            new ImageIcon("images/globe.gif"));
    }

    static void helloMars() {
        JOptionPane.showMessageDialog(
            null,
            "Hello, Mars!",
            "Greeting",
            JOptionPane.INFORMATION_MESSAGE,
            new MarsIcon(80));
    }

    static void helloMars2() {
        try {
            JOptionPane.showMessageDialog(
                null,
                "Hello, Mars!",
                "Greeting",
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(new URL("https://nssdc.gsfc.nasa.gov/image/planetary/mars/marsglobe3.jpg")));
        } catch (MalformedURLException ex) {
            Logger.getLogger(IconTester.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
