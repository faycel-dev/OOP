package iconTest;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
   An icon that has the shape of the planet Mars.
*/
public class MarsIcon implements Icon
{
   private int size;

   /**
      Constructs a Mars icon of a given size.
   */
   public MarsIcon(int size) {
      this.size = size;
   }

   public int getIconWidth() {
      return size;
   }

   public int getIconHeight() {
      return size;
   }

   public void paintIcon(Component c, Graphics g, int x, int y) {
      Graphics2D g2 = (Graphics2D) g;
      g2.setPaint( new GradientPaint (x, y, Color.YELLOW, x+size, y+size, Color.RED) );
      Ellipse2D.Double planet = new Ellipse2D.Double(x, y, size-1, size-1);
      g2.fill(planet);
   }

}
