package Order;

public interface Payment {
    void pay( double amount );
}
