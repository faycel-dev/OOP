/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;
import java.util.Locale;
import java.util.Scanner;
/**
 *
 * @author fayce
 */
public class GallowsUI {
  private Gallows game;
    private Scanner myscanner;
public GallowsUI()
{
    myscanner=new Scanner(System.in);
}
public void play()
{
    System.out.println("Welcom to Hangman!");
    System.out.println("Please enter a word or press Enter to randomly pick on :");

    myscanner.useDelimiter("[^a-zA-Z]+");
    String in=myscanner.nextLine();
    if(in.isEmpty())
    {
        game=new Gallows();
        System.out.println("Randomly picking a word.");
    }
    else
    {
        game=new Gallows(in);
    }
    System.out.println("\nRemaining mistakes: "+game.getTries());
    System.out.println("Guessed letters: "+"["+game.getGuessedletters()+"]");
    System.out.println("word: "+ game.getSecret() + "\n");

    while(!game.wordguessed() && ! game.numberoftries())
    {
        System.out.println("Enter a letter: ");
        char c=myscanner.next().charAt(0);
        try{
            game.guessletter(c);
        } catch(Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println("\nRemaining mistakes: "+game.getTries());
        System.out.println("Guessed letters: "+"["+game.getGuessedletters()+"]");
        System.out.println("word: "+ game.getSecret() + "\n");
    }
    if(game.wordguessed()&& !game.numberoftries())
    {
        System.out.println("Congratulations you win!");
    }
    else
    {
        System.out.println("try again!!");
    }
    
}
}
