/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman;

/**
 *
 * @author fayce
 */
public class Gallows {
        private String word;
    private StringBuilder guessedletters;
    private StringBuilder secret;
    private int tries;

    public Gallows(String word){
        this.word=word;
        this.secret=new StringBuilder(lettertoDot(word.length()));
        this.guessedletters=new StringBuilder();
        this.tries=10;
    }
    
    public boolean wordguessed()
{
    return secret.toString().compareTo(word)==0;
}
public String getSecret()
{
    return secret.toString();
}
public String getGuessedletters()
{
    return guessedletters.toString();
}
public int getTries()
{
    return tries;
}
    public String lettertoDot(int size){
        StringBuilder out=new StringBuilder();
        for (int i=0;i<size;i++){
            out.append('.');
        }
        return out.toString();
    }
    public Gallows(){
        WordReader file = new WordReader("words.txt");
        this.word= file.getWord();
        this.secret=new StringBuilder(lettertoDot(word.length()));
        this.guessedletters=new StringBuilder();
        this.tries=10;
    }
    private boolean occursinword(char c)
    {
        return word.indexOf(c)!= -1;
    }
    private void updatesecret(char c)
    {
        int i=word.indexOf(c);
        while(i!=-1)
        {
            secret.setCharAt(i,c);
            i=word.indexOf(c,++i);
        }
    }
   private boolean letteringuessedletters(char c)
   {
       return guessedletters.toString().indexOf(c)!=-1;
   }
    public boolean numberoftries()
    {
        return tries<1;
    }
    public void guessletter(char c)
    {
        guessedletters.append(c);
        if(occursinword(c)){
            updatesecret(c);
        }
        else
        {
            tries--;
        }
    }

    
}
