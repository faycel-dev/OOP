package quadtrees;

import java.io.IOException;
import java.io.Writer;

public class GreyNode implements QuadTreeNode{
    private QuadTreeNode[] child;
    public GreyNode(QuadTreeNode[] child){
        this.child=child;
    }
    @Override
    public void fillBitmap(int x, int y, int width, Bitmap bitmap) {
        child[0].fillBitmap(x,y,width/2,bitmap);
        child[1].fillBitmap(x+width/2,y,width/2,bitmap);
        child[2].fillBitmap(x+width/2,y+width/2,width/2,bitmap);
        child[3].fillBitmap(x,y+width/2,width/2,bitmap);
    }

    @Override
    public void writeNode(Writer out) {
        try{
            out.append("1");
        }catch(IOException e){
            e.printStackTrace();
        }
        for(QuadTreeNode c :child){
            c.writeNode(out);
        }

    }
}
