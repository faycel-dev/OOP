/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutorial7.listit;

import java.util.Iterator;
import java.util.ListIterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author sjakie
 */

public class MyLinkedListTest {
   
   public MyLinkedListTest() {
   }
   

   @Test
   public void testSize() {
      String testStr = "Hello world!";
      MyLinkedList<Character> mll = new MyLinkedList<>();
      for (char c : testStr.toCharArray()){
         mll.add(c);
      }
      assertEquals("size", testStr.length(), mll.size());
   }

   @Test
   public void testAddAndGet() {
      String testStr = "Hello world!";
      MyLinkedList<Character> mll = new MyLinkedList<>();
      for (char c : testStr.toCharArray()){
         mll.add(c);
      }
      for ( int i = 0; i < testStr.length(); i++ ) {
         assertEquals("get elem " + i, testStr.charAt(i), (char) mll.get(i));
      }
   }

   @Test
   public void testListIterator() {
      String testStr = "Hello world!";
      MyLinkedList<Character> mll = new MyLinkedList<>();
      for (char c : testStr.toCharArray()){
         mll.add(c);
      }
      ListIterator<Character> mlLit = mll.listIterator();
      int nextCharInd = 0;
      while ( mlLit.hasNext() ){
         assertEquals("Iterator next " + nextCharInd, testStr.charAt(nextCharInd), (char) mlLit.next());
         nextCharInd++;
      }
   }


   
   
}
