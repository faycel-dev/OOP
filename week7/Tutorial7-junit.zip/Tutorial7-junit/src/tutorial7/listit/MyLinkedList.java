package tutorial7.listit;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 *
 * @version 1.0
 */
public class MyLinkedList<E> extends AbstractList<E> {

   private Node<E> head, tail;
   private int size;

   @Override
   public E get(int index) {
      return getNode(index).elem;
   }

   @Override
   public int size() {
      return size;
   }

   private static class Node<EL> {

      private EL elem;
      private Node<EL> previous, next;

      public Node(EL elem, Node<EL> previous, Node<EL> next) {
         this.elem = elem;
         this.previous = previous;
         this.next = next;
      }

      public Node(EL elem) {
         this(elem, null, null);
      }
   }

   private void addToFront(E e) {
      if (head == null) {
         head = tail = new Node<>(e);
      } else {
         head = head.previous = new Node<>(e, null, head);
      }
   }

   private Node<E> getNode(int n) {
      if ( n >= size ) {
         throw new NoSuchElementException();         
      }
      if (n < size / 2) {
         Node<E> nextNode = head;
         for (int i = 0; i < n; i++) {
            nextNode = nextNode.next;
         }
         return nextNode;
      } else {
         Node<E> prevNode = tail;
         for (int i = 1; i < size - n; i++) {
            prevNode = prevNode.previous;
         }
         return prevNode;
      }
   }

   @Override
   public boolean add(E elem) {
      if (head == null) {
         head = tail = new Node(elem);
      } else {
         tail = tail.next = new Node(elem, tail, null);
      }
      size++;
      return true;
   }

   @Override
   public Iterator<E> iterator() {
      return new MyListIterator(head);
   }

   @Override
   public ListIterator<E> listIterator() {
      return new MyListIterator(head);
   }

   @Override
   public ListIterator<E> listIterator(int n) {
      return new MyListIterator(getNode(n));
   }

   private class MyListIterator implements ListIterator<E> {
      Node<E> nextNode, prevNode;

      public MyListIterator(Node<E> nextNode) {
         this.nextNode = nextNode;
         if (nextNode != null) {
            prevNode = nextNode.previous;
         }
      }

      @Override
      public boolean hasNext() {
         return nextNode != null;
      }

      @Override
      public E next() {
         if (nextNode != null) {
            prevNode = nextNode;
            nextNode = prevNode.next;
            return prevNode.elem;
         } else {
            throw new NoSuchElementException();
         }

      }
   

      @Override
      public boolean hasPrevious() {
         return prevNode != null;
      }

      @Override
      public E previous() {
         if (prevNode != null) {
            nextNode = prevNode;
            prevNode = prevNode.previous;
            return nextNode.elem;
         } else {
            throw new NoSuchElementException();
         }
      }

      @Override
      public void remove() {
         if ( prevNode == null) {
            throw new NoSuchElementException();
         } 
         if (prevNode.previous == null) {
            if (prevNode.next == null) {
               head = tail = prevNode = null;
            } else {
               head = prevNode.next;
               prevNode = head.previous = null;
            }
         } else if (prevNode.next == null) {
            prevNode = tail = tail.previous;
            tail.next = null;
         } else {
            prevNode = prevNode.previous;
            prevNode.next = nextNode;
            nextNode.previous = prevNode;
         }
         size--;
      }

      @Override
      public void add(E e) {
         if (prevNode == null) {
            addToFront(e);
            prevNode = head;
         } else {
            prevNode = new Node<>(e, prevNode, prevNode.next);
            prevNode.previous.next = prevNode;
            if (prevNode.next == null) {
               tail = prevNode;
            } else {
               prevNode.next.previous = prevNode;
            }
         }
         size++;
      }

      @Override
      public int nextIndex() {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      }

      @Override
      public int previousIndex() {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      }

      @Override
      public void set(E e) {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      }

   }

}
