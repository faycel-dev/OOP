package tutorial7.listit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @version 1.0
 */
public class Tutorial7ListIt {

    public static void main(String[] args) {
        run();
    }

    static void run(){
      String testString = "Hello world!";
      MyLinkedList<Character> mll = new MyLinkedList<>();
      for (char c : testString.toCharArray()){
         mll.add(c);
      }
      ListIterator<Character> llit = mll.listIterator();
      while ( llit.hasNext() ) {
         System.out.print(llit.next());
      }
      llit = mll.listIterator(mll.size()/2);
      while ( llit.hasPrevious() ) {
         llit.remove();
      }
      for (char c : "Bye moon?".toCharArray()){
         llit.add(c);
      }
      System.out.println();
      while ( llit.hasPrevious() ) {
         System.out.print(llit.previous());
      }
      System.out.println();
      for ( int i = 0; i < mll.size(); i++ ) {
         System.out.print(mll.get(i));
      }
    }
}
