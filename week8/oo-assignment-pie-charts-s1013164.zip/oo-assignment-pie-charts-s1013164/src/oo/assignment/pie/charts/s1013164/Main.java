/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oo.assignment.pie.charts.s1013164;

import java.util.LinkedList;
import java.util.List;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.converter.NumberStringConverter;

/**
 *
 * @author fayce
 */
public class Main extends Application {

    /**
     * @param args the command line arguments
     */
    
     @Override
    public void start(Stage stage) {
        List<IntegerProperty>intP=new LinkedList<>();
        List<DoubleProperty> doubleP=new LinkedList<>();
        List<IntegerProperty>sum=new LinkedList<>();
        IntegerProperty sumP=new SimpleIntegerProperty();
        
        GridPane root=new GridPane();
        root.setAlignment(Pos.CENTER);
        root.setHgap(20);
        root.setVgap(10);
        
        for(int i=0;i<4;i++){
            intP.add(new SimpleIntegerProperty(1));
            doubleP.add(new SimpleDoubleProperty());
            
        TextField textField=new TextField();
        textField.textProperty().bindBidirectional(intP.get(i),new NumberStringConverter());
       textField.textProperty().addListener(new ChangeListener <String >() {
         @Override
         public void changed(ObservableValue <? extends String> observable ,String oldValue, String newValue) {
               if (!newValue.matches("[1-9]\\d{0,3}")) {textField.setText(oldValue);
               } } });
       
       
       doubleP.get(i).bind(intP.get(i).add(0d).divide(sumP));
       
       sum.add(new SimpleIntegerProperty());
       if(i==0){
           sum.get(i).bind(intP.get(i));
       }else{
           sum.get(i).bind(sum.get(i-1).add(intP.get(i)));
       }
       
       Label label=new Label();
       label.textProperty().bind(Bindings.format("%.2f",doubleP.get(i)));
       
       
       root.add(textField,0,i);
       root.add(label,1,i);
    }
        sumP.bind(sum.get(3));
        Scene scn=new Scene(root,300,200);
        stage.setTitle("pie-chart");
        stage.setScene(scn);
        stage.show();
    }
    public static void main(String[] args) {
        // TODO code application logic here
        launch();
    }
    
}
