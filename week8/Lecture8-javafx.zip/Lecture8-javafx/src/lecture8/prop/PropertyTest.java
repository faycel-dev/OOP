package lecture8.prop;

import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @version 1.0
 */
public class PropertyTest {

   public static void main(String[] args) {
      run2();
   }

   private static void run() {
      IntegerProperty x = new SimpleIntegerProperty(2);
      IntegerProperty y = new SimpleIntegerProperty(7);
      IntegerProperty z = new SimpleIntegerProperty(3);
      print(x, y);
      y.bind(x);
      print(x, y);
      y.bind(x.multiply(z).add(2));
      print(x, y);
      z.set(5);
      print(x, y);
      y.set(5);
   }

  public static void run1() {       
    DoubleProperty d1 = new SimpleDoubleProperty(1);
    DoubleProperty d2 = new SimpleDoubleProperty(2);
    d1.bindBidirectional(d2);
    print(d1, d2);
    d1.setValue(50.1);
    print(d1, d2);
    d2.setValue(70.2);
    print(d1, d2);
  }
   
   private static void print(IntegerProperty a, IntegerProperty b) {
      System.out.printf("%d, %d\n", a.intValue(), b.intValue());
   }
   
   private static void print(DoubleProperty a, DoubleProperty b) {
      System.out.printf("%f, %f\n", a.doubleValue(), b.doubleValue());
   }
   
   private static void run2() {
      IntegerProperty x = new SimpleIntegerProperty(1);
      IntegerProperty y = new SimpleIntegerProperty(7);
      StringProperty s = new SimpleStringProperty();
      s.bind(Bindings.concat("X has value ", x, ", Y has value ", y));
      print(s);
      y.bind(x);
      print(s);
      y.bind(x.multiply(8).add(2));
      print(s);
      x.set(5);
      print(s);
   }

   private static void print(StringProperty s) {
      System.out.println(s.getValue());
   }

}
