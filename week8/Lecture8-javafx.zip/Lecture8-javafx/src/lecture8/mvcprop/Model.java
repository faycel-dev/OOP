package lecture8.mvcprop;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


/**
 *
 * @version 1.0
 */
public class Model {
   private final IntegerProperty modelAttr;

   public Model(int modAttr) {
      this.modelAttr = new SimpleIntegerProperty(modAttr);
   }
   
   public IntegerProperty modelAttrProperty () {
      return modelAttr;
   }

   public int getModelAttr() {
      return modelAttr.getValue();
   }
   
   public void setModelAttr(int modAttr) {
      modelAttr.setValue(modAttr);
   }
}
