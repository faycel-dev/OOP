package lecture8.mvcprop;

import lecture8.mvc.*;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class Main extends Application {

   @Override
   public void start(Stage stage) {
      Label label = new Label();
      View view = new View(label);
      Model model = new Model(42);
      view.labelProperty().bind(Bindings.concat("Model: ", model.modelAttrProperty()));
      Pane root = new StackPane(label);
      Scene scene = new Scene(root, 200, 100);
      stage.setTitle("MVC App");
      stage.setScene(scene);
      stage.show();
      model.setModelAttr(4711);
   }

   public static void main(String[] args) {
      launch(args);
   }
}
