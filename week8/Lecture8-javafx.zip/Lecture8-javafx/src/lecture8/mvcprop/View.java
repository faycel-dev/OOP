package lecture8.mvcprop;

import javafx.beans.property.StringProperty;
import lecture8.mvc.*;
import javafx.scene.control.Label;

/**
 *
 * @version 1.0
 */
public class View {
   private final Label label;

   public View(Label label) {
      this.label = label;
   }
   
   public StringProperty labelProperty(){
      return label.textProperty();
   }   
}
