package lecture8.center;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class Center extends Application {

   public void start(Stage stage) {
      stage.setTitle("Stage 3");
      Circle circle3 = new Circle(50);
      circle3.centerXProperty().bind(stage.widthProperty().multiply(0.5));
      circle3.centerYProperty().bind(stage.heightProperty().multiply(0.5));
      stage.setScene(new Scene(new Pane(circle3), 200, 200));
      stage.show();
   }
   
   public static void main(String[] args) {
      launch(args);
   }

}
