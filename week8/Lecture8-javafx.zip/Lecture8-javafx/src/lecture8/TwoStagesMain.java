package lecture8;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class TwoStagesMain extends Application {

   @Override
   public void start(Stage stage) {
      Circle circle = new Circle(100, 50, 40);
      circle.setFill(Color.RED);
      Pane pane = new Pane(circle);
      Scene scene = new Scene(pane, 200, 100);
      stage.setTitle("My JavaFX App");
      stage.setScene(scene);
      stage.show();

      Stage stage2 = new Stage();
      stage2.setTitle("Stage 2");
      Circle circle2 = new Circle(10, 10, 40);
      circle2.setFill(Color.BLUE);
      stage2.setScene(new Scene(new StackPane(circle2), 200, 100));
      stage2.show();
   }

   public static void main(String[] args) {
      launch(args);
   }

}
