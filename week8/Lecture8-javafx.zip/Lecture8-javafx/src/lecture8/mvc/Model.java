package lecture8.mvc;

/**
 *
 * @version 1.0
 */
public class Model {
   private int modelAttr;
   private View viewAttr;

   public Model(int modAttr, View view) {
      this.modelAttr = modAttr;
      this.viewAttr  = view;
      viewAttr.setText("model attribute: " + modelAttr);
   }
   
   public int getModAttr() {
      return modelAttr;
   }

   public void setModAttr(int modAttr) {
      this.modelAttr = modAttr;
      viewAttr.setText("model attribute: " + modelAttr);
   }
}
