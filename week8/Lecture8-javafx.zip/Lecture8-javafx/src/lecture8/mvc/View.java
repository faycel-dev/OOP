package lecture8.mvc;

import javafx.scene.control.Label;

/**
 *
 * @version 1.0
 */
public class View {
   Label label;

   public View(Label label) {
      this.label = label;
   }
   
   void setText (String txt ) {
      label.setText(txt);
   }
}
