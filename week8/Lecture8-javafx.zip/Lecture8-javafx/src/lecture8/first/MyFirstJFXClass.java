package lecture8.first;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class MyFirstJFXClass extends Application {

   @Override
   public void start(Stage stage) {
      Circle circle = new Circle(100, 50, 40);
      Pane root = new Pane(circle);
      Scene scene = new Scene(root, 200, 100);
      stage.setTitle("My JavaFX App");
      stage.setScene(scene);
      stage.show();
   }

   public static void main(String[] args) {
      launch(args);
      System.out.println("launch ended");
   }
}
