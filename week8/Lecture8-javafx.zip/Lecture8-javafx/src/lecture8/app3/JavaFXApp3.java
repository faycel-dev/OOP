package lecture8.app3;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class JavaFXApp3 extends Application {
  IntegerProperty counter = new SimpleIntegerProperty(); // should be in a model

  @Override
  public void start(Stage primaryStage) {
    Label  lbl = new Label("press the button");
    lbl.textProperty().bind(Bindings.concat("pressed ", counter, " times"));
    Button btn = new Button("press me");
    btn.setOnAction( e -> counter.set(counter.intValue() + 1) );
    Pane root = new Pane();
    root.getChildren().addAll(btn, lbl);
    primaryStage.setTitle(this.getClass().getName());
    primaryStage.setScene(new Scene(root, 300, 250));
    primaryStage.show();
  }
   public static void main(String[] args) {
      launch(args);
   }
}