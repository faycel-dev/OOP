package lecture8.rectangle;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @version 1.0
 */
public class RorRect extends Application {

   public void start1(Stage primaryStage) {
      Rectangle rect = new Rectangle(200, 100);
      rect.setStyle("-fx-fill: thistle; -fx-stroke: purple; -fx-stroke-width: 3; -fx-arc-height: 40; -fx-arc-width: 50");
      Label label = new Label("Click to turn");
      label.setStyle("-fx-text-fill: midnightblue;  -fx-font-size: 20; -fx-font-weight: bold");
      StackPane root = new StackPane(rect, label);
      root.setStyle("-fx-background-color: plum;");
      Scene scene = new Scene(root, 300, 250);
      root.setOnMouseClicked(e -> root.setRotate(root.getRotate() + 15));
      primaryStage.setTitle(this.getClass().getSimpleName());
      primaryStage.setScene(scene);
      primaryStage.show();
   }
   public void start(Stage primaryStage) {
      Rectangle rect = new Rectangle(200, 100);
      rect.setArcHeight(40);
      rect.setArcWidth(60);
      rect.setFill(Color.ORANGE);
      rect.setStroke(Color.DARKORANGE);
      rect.setStrokeWidth(3);
      Label label = new Label("Click to turn");
      label.setTextFill(Color.WHITE);
      StackPane root = new StackPane(rect, label);
      Scene scene = new Scene(root, 300, 250);
      root.setOnMouseClicked(e -> root.setRotate(root.getRotate() + 15));
      primaryStage.setTitle(this.getClass().getSimpleName());
      primaryStage.setScene(scene);
      primaryStage.show();
   }
   public static void main(String[] args) {
      launch(args);
   }


}
