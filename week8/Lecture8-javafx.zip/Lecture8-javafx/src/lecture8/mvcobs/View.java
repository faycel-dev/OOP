package lecture8.mvcobs;

import javafx.scene.control.Label;

/**
 *
 * @version 1.0
 */
public class View implements Observer<Model>{
   Label label;

   public View(Label label) {
      this.label = label;
   }
   
   void setText (String txt ) {
      label.setText(txt);
   }

   @Override
   public void update(Model observable) {
      label.setText("Model: " + observable.getModAttr());
   }
}
