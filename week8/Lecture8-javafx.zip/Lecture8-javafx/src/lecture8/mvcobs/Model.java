package lecture8.mvcobs;


/**
 *
 * @version 1.0
 */
public class Model {
   private int modelAttr;
   private Observer<Model> viewAttr;

   public Model(int modAttr, Observer<Model> view) {
      this.modelAttr = modAttr;
      this.viewAttr  = view;
      viewAttr.update( this );
   }
   
   public int getModAttr() {
      return modelAttr;
   }

   public void setModAttr(int modAttr) {
      this.modelAttr = modAttr;
      viewAttr.update( this );
   }
}
