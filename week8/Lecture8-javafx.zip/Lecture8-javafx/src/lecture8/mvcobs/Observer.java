package lecture8.mvcobs;

/**
 *
 * @version 1.0
 */
public interface Observer<T> {
   void update( T observable );
}
