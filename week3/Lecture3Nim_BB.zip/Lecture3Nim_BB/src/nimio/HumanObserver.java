package nimio;

import nimmodel.HumanStrategy;


/**
 * Models an object that needs to be informed when an human player is about to
 * make a play.
 */
public interface HumanObserver {

    /**
     * The specified HumanPlayer is about to make a play.
     */
    public void update( HumanStrategy player, int maxOnATurn );
}
