
package nimmodel;

/**
 *
 * @author Sjaak Smetsers <s.smetsers@cs.ru.nl>
 */
public class TimidStrategy implements PlayStrategy {

    @Override
    public int numberToTake(Pile pile, int maxOnATurn) {
        return 1;
    }

}
