package nimmodel;

import nimio.HumanObserver;
import static java.lang.Integer.min;

/**
 *
 * @author Sjaak Smetsers <s.smetsers@cs.ru.nl>
 */
public class HumanStrategy implements PlayStrategy {

    private int myNumberToTake;
    private HumanObserver myController;  // Observer this Player reports to.
    
    
    @Override
    public int numberToTake( Pile pile, int maxOnATurn ) {
        myController.update( this, min( maxOnATurn, pile.sticks() ) );    // numberToTake set here        
        return myNumberToTake;
    }
    
    public void setNumberToTake( int number ) {
        myNumberToTake = number;
    }
    public void register( HumanObserver controller ) {
        myController = controller;
    }

}
