package nimmodel;

/**
 * A pile of sticks for playing simple nim.
 */
public class Pile {

    private int sticks;  // number of stick in this Pile

    public Pile(int sticks) {
        this.sticks = sticks;
    }

    public int sticks() {
        return sticks;
    }

    public void remove(int number) {
        assert 0 <= number && number <= sticks :
                "precondition: number <= this.sticks()";
        sticks = sticks - number;
    }

    @Override
    public String toString() {
        return "Pile: " + sticks + " sticks.";
    }
}
