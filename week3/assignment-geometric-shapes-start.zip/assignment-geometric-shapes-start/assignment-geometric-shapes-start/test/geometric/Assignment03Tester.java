package geometric;

public class Assignment03Tester {

	public Assignment03Tester() {
	}

	public void createCircle(double x, double y, double r) {
	}

	public void createRectangle(double x, double y, double width, double height) {
	}

	public double topBorder(int index) {
		return 0.0;
	}

	public double rightBorder(int index) {
		return 0.0;
	}

	public double bottomBorder(int index) {
		return 0.0;
	}

	public double leftBorder(int index) {
		return 0.0;
	}

	public double area(int index) {
		return 0.0;
	}

	public void move(int index, double dx, double dy) {
	}

	public void sortByArea() {
	}

	public void sortByX() {
	}

	public void sortByY() {
	}
}
