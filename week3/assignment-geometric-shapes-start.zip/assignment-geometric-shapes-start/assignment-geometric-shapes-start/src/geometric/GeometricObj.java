package geometric;

import java.util.Arrays;
import java.util.InputMismatchException;

public class GeometricObj {
    private Geometric[] objects;
    public GeometricObj(int size){
        this.objects=new Geometric[size];
    }
    public Geometric[] getObjects(){
        return objects;
    }
    public void quit(){
        System.exit(0);
    }
    public String show(){
        StringBuilder st=new StringBuilder();
        int i=0;
        for(Geometric a:objects){
            if(a==null){
                st.append(i++).append(".").append("no object").append("\n");
            }else{
                st.append(i++).append(".").append(a.toString()).append("\n");
            }
        }
        st.append('\n');
        return st.toString();
    }
    public void addCircle(double x,double y,double r){
        int i=0;
        while(objects[i]!=null){
            i++;
        }
        objects[i]=new Circle(x,y,r);
    }
    public void addRectangle(double x,double y,double w,double h){
        int i=0;
        while(objects[i]!=null){
            i++;
        }
        objects[i]=new Rectangle(x,y,w,h);
    }
    public void move(int i,double dx,double dy){
        objects[i].move(dx,dy);
    }
    public void remove(int i){
        if(i>0 && i<objects.length){
            objects[i]=null;
            shiftleft(i);
        }else{
            throw new InputMismatchException("intdex shoud be between 0 and "+ objects.length);
        }
    }

    private void shiftleft(int i) {
        for(int j=i+1;j<objects.length;j++){
            if(objects[j]!=null){
                objects[j-1]=objects[j];
                objects[j]=null;
            }
        }
    }
    public void sort(char c){
        int i=0;
        while(objects[i]!=null){
            i++;
        }
        switch(c){
            case 'x': Arrays.sort(objects,0,i,new Xcomparator());
              break;
            case 'y':Arrays.sort(objects,0,i,new Ycomparator());
               break;
        }
    }
    public void sort(){
        int i=0;
        while(objects[i]!=null){
            i++;
        }
        Arrays.sort(objects,0,i);
    }
}
