package geometric;

import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class View {
    private Scanner myscan;
    public View(){
        this.myscan=new Scanner(System.in);
    }
    public String getCommand(){
        System.out.println("Please enter a command!: ");
        return myscan.next().toLowerCase();
    }
    public void handelcommand(){
        System.out.println("check your command!!!!");
    }
    public double getDouble(){
        double a=333;
        if(myscan.hasNextDouble()){
            try{
                a=myscan.nextDouble();
            }catch(InputMismatchException e){
                System.out.println("not valid");
            }
        }
        return a;
    }
    public int getInt(){
        return myscan.nextInt();
    }
    public char getChar(){
        return myscan.next().toLowerCase().charAt(0);
    }
    public String getNextLine(){
        return myscan.nextLine();
    }
    public void print(String input){
        System.out.println(input);
    }
}
