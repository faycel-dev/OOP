package geometric;
import java.util.Comparator;
public class Xcomparator implements Comparator<Geometric>{
@Override
    public int compare(Geometric a,Geometric b){
    return Double.compare(a.leftBorder(),b.leftBorder());
}
}
