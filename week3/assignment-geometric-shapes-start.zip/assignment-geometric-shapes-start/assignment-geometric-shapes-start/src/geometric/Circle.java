package geometric;

public class Circle implements Geometric {
    private double radius;
    private double coordinateX;
    private double coordinateY;
    public Circle(double radius,double coordinateX,double  coordinateY){
        this.radius=radius;
        this.coordinateX =coordinateX;
        this.coordinateY =coordinateY;
    }

    @Override
    public double leftBorder(){
      return coordinateX - radius;
    }
    @Override
    public double rightBorder(){
        return coordinateX + radius;
    }
    @Override
    public double topBorder(){
        return coordinateY + radius;
    }
    @Override
    public double bottomBorder(){
        return coordinateY - radius;
    }
    @Override
    public double area(){
        return Math.PI*radius*radius;
    }
    @Override
    public void move(double dx,double dy){
        this.coordinateX +=dx;
        this.coordinateY +=dy;
    }
    @Override
    public int compareTo(Geometric a){
        return Double.compare(this.area(),a.area());
    }
    @Override
    public String toString(){
        return "Circle \t {(" + "x=" + coordinateX + ", y=" + coordinateY + ") , r=" + radius + '}';
    }
}
