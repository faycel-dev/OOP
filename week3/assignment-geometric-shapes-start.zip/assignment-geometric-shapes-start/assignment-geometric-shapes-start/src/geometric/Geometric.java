package geometric;

public interface Geometric extends Comparable<Geometric>{
    double leftBorder();

    double rightBorder();

    double topBorder();

    double bottomBorder();

    double area();

    void move(double dx, double dy);

    int compareTo(Geometric a);
}
