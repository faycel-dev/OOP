package geometric;
import java.util.Comparator;
public class Ycomparator implements Comparator<Geometric>{
@Override
    public int compare(Geometric a,Geometric b){
    return Double.compare(a.bottomBorder(),b.bottomBorder());
}
}
