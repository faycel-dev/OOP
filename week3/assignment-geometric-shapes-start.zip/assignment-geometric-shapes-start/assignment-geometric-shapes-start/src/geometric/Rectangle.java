package geometric;

public class Rectangle implements Geometric{
    private double coordinateX;
    private double coordinateY;
    private double width;
    private double height;
    public Rectangle(double coordinateX,double coordinateY,double width,double height){
        this.coordinateX =coordinateX;
        this.coordinateY =coordinateY;
        this.height=height;
        this.width=width;
    }
    @Override
    public double leftBorder(){

        return coordinateX;
    }
    @Override
    public double rightBorder(){
        return coordinateX + width;
    }
    @Override
    public double topBorder(){
        return coordinateY + height;
    }
    @Override
    public double bottomBorder(){
        return coordinateY;
    }
    @Override
    public double area(){
        return height*width;
    }

    @Override
    public void move(double dx,double dy){
        this.coordinateX +=dx;
        this.coordinateY +=dy;
    }
    @Override
    public int compareTo(Geometric a){
        return Double.compare(this.area() , a.area());
    }
    @Override
    public String toString(){
        return "rectangle \t {(" + "x="+ coordinateX + ", y=" + coordinateY + ") , weight=" + width + ", height=" + height +'}';
    }
}
