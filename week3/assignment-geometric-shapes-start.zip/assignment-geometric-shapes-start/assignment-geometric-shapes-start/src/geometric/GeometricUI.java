package geometric;

public class GeometricUI {
    private View view;
    private GeometricObj model;
    public GeometricUI(){
        this.view=new View();
        this.model=new GeometricObj(10);
    }
    public void start(){
        String command=view.getCommand();
        while(!command.equals("quit")){
            switch(command){
                case "show" : view.print(model.show());
                     break;
                case "circle": model.addCircle(view.getDouble(),view.getDouble(),view.getDouble());
                   break;
                case "rectangle":model.addRectangle(view.getDouble(),view.getDouble(),view.getDouble(),view.getDouble());
                    break;
                case "move": model.move(view.getInt(), view.getDouble(), view.getDouble());
                   break;
                case "remove":model.remove(view.getInt());
                   break;
                case "sort": String a=view.getNextLine();
                             if(a.isEmpty()){
                                 model.sort();
                             }else{
                                 model.sort(a.charAt(1));
                             }
                    break;
                default :view.handelcommand();
                       break;
            }
            command= view.getCommand();
        }
    }
}
