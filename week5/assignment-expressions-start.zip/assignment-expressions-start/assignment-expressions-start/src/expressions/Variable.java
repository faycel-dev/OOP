package expressions;

import java.util.Map;

public class Variable extends NoArgExpr{
    private final String str;
    public Variable(String str){
        this.str=str;
    }
    @Override
    public String toString()
    {
        return str;
    }

    @Override
    public Expression partialEval() {
        return new Variable(str);
    }

    @Override
    public double eval(Map<String, Double> env) {
        return env.get(str);
    }
}
