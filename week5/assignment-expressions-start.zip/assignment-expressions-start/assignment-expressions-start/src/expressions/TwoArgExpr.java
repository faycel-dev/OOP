package expressions;

import java.util.Map;
import java.util.function.BinaryOperator;

public abstract class TwoArgExpr implements Expression{
  private final Expression x,y;
  private final BinaryOperator<Double> op;
  private final BinaryOperator<Expression> exop;


    protected TwoArgExpr(Expression x, Expression y, BinaryOperator<Double> op, BinaryOperator<Expression> exop) {
        this.x=x;
        this.y=y;
        this.exop=exop;
        this.op=op;

    }

    @Override
    public double eval(Map<String, Double> env) {
        return op.apply(x.eval(env),y.eval(env));
    }

    @Override
    public Expression partialEval() {
        return exop.apply(x.partialEval(),y.partialEval());
    }

    @Override
    public String toString(){
        return "(" + x + getOperator() + y + ")";
    }

    protected abstract String getOperator();
}
