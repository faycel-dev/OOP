package expressions;

import java.util.Map;

public abstract class NoArgExpr implements Expression{



}
