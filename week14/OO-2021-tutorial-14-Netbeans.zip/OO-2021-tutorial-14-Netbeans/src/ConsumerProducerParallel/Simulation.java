/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConsumerProducerParallel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author dku
 */
public class Simulation {
    private final SharedBuffer sharedBuffer;
    private final Producer producer;
    private final Consumer consumer;
            
    public Simulation() {
        sharedBuffer = new SharedBuffer();
        producer = new Producer(sharedBuffer);
        consumer = new Consumer(sharedBuffer);
    }
    
    void shutdownAndAwaitTermination(ExecutorService exec) {
        exec.shutdown();
        try {
            if (!exec.awaitTermination(1, TimeUnit.MINUTES)) {
                exec.shutdownNow();
                if (!exec.awaitTermination(1, TimeUnit.MINUTES)) {
                    System.err.println("Executor did not terminate");
                }
            }
        } catch (InterruptedException e) {
            exec.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
    
    public void start() {
        ExecutorService e = Executors.newCachedThreadPool();
        e.execute(producer);
        e.execute(consumer);
        shutdownAndAwaitTermination(e);
    }
      
    public void showStatistics() {
        System.out.println("Total number of items produced equals " + producer.getTotalNumberOfItemsProduced());
        System.out.println("Total number of items consumed equals " + consumer.getTotalNumberOfItemsConsumed());
    }
}
