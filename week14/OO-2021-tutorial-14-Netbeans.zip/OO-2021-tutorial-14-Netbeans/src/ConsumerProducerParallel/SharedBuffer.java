/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConsumerProducerParallel;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dku
 */
public class SharedBuffer {
    private static final int CAPACITY = 10;
    private final LinkedList<Integer> queue = new LinkedList<>();
    private final Lock lock = new ReentrantLock();
    private final Condition bufferIsNotFull = lock.newCondition();
    private final Condition bufferIsNotEmpty = lock.newCondition();
    private boolean bufferClosed = false;
    
    public void write(int value) {
        lock.lock();
        try {
            while (isFull()) {
                System.out.println("Wait until buffer is not full");
                bufferIsNotFull.await();
            }
            queue.offer(value);
            bufferIsNotEmpty.signalAll();
        } catch (InterruptedException ex) {
            Logger.getLogger(SharedBuffer.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            lock.unlock();
        }
    }
    
    public int read() {
        int value = 0;
        lock.lock();
        try {
            while (isEmpty()) {
                System.out.println("Wait until buffer is not empty");
                bufferIsNotEmpty.await();
            }
            value = queue.remove();
            bufferIsNotFull.signalAll();
            return value;
        } catch (InterruptedException ex) {
            Logger.getLogger(SharedBuffer.class.getName()).log(Level.SEVERE, null, ex);
            return value;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isEmpty() {
        lock.lock();
        try {
            return queue.isEmpty();
        } finally {
            lock.unlock();
        }
    }
    
    public void close() {
        lock.lock();
        try {
            bufferClosed = true;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isClosed() {
        lock.lock();
        try {
            return bufferClosed;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isFull() {
        lock.lock();
        try {
            return queue.size() == CAPACITY;
        } finally {
            lock.unlock();
        }
    }
}
