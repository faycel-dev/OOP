/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConsumerProducer;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dku
 */
public class Producer implements Runnable {
    private final SharedBuffer sharedBuffer;
    private int currentValue;
    private final int NR_OF_ITEMS_TO_BE_PRODUCED = 5;
    
    public Producer(SharedBuffer sharedBuffer) {
        this.sharedBuffer = sharedBuffer;
        currentValue = 0;
    }
    
    @Override
    public void run() {
        while (currentValue < NR_OF_ITEMS_TO_BE_PRODUCED) {
            produce();
        }
        sharedBuffer.close();
    }
    
    public void produce() {
        System.out.println("Producer writes " + currentValue);
        sharedBuffer.write(currentValue);
        currentValue++;
        try {
            TimeUnit.SECONDS.sleep(Util.getRandomNumber(1, 3));
        } catch (InterruptedException ex) {
            Logger.getLogger(Producer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int getTotalNumberOfItemsProduced() {
        return currentValue;
    }
}
