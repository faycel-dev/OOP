/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConsumerProducer;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dku
 */
public class Consumer implements Runnable {
    private final SharedBuffer sharedBuffer;
    private int totalNumberOfItemsConsumed;
    
    public Consumer(SharedBuffer sharedBuffer) {
        this.sharedBuffer = sharedBuffer;
        totalNumberOfItemsConsumed = 0;
    }
    
    @Override
    public void run() {
        while(!sharedBuffer.isClosed()) {
            consume();
        }
        
        while (!sharedBuffer.isEmpty()) {
            consume();
        }
    }
    
    public void consume() {
        System.out.println("\t\t\tConsumer read " + sharedBuffer.read());
        totalNumberOfItemsConsumed++;
        try {
            TimeUnit.SECONDS.sleep(Util.getRandomNumber(1, 3));
        } catch (InterruptedException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int getTotalNumberOfItemsConsumed() {
        return totalNumberOfItemsConsumed;
    }
}
