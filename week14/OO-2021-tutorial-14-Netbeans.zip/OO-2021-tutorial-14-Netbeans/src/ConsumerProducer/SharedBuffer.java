/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConsumerProducer;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dku
 */
public class SharedBuffer {
    private static final int CAPACITY = 10;
    private final LinkedList<Integer> queue = new LinkedList<>();
    private final Lock lock = new ReentrantLock();
    private final Condition notFull = lock.newCondition();
    private final Condition notEmpty = lock.newCondition();
    private boolean isClosed = false;
    
    public void write(int value) {
        lock.lock();
        try {
            while (isFull()) {
                notFull.await();
            }
            queue.offer(value);
            notEmpty.signalAll();
        } catch (InterruptedException ex) {
            Logger.getLogger(SharedBuffer.class.getName()).log(Level.SEVERE, null, ex);
        } finally { 
            lock.unlock();
        }
    }
    
    public int read() {
        int value = 0;
        lock.lock();
        try {
            while (isEmpty()) {
                notEmpty.await();
            }
            value = queue.remove();
            notFull.signalAll();
            return value;
        } catch (InterruptedException ex) {
            Logger.getLogger(SharedBuffer.class.getName()).log(Level.SEVERE, null, ex);
            return value;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isEmpty() {
        lock.lock();
        try {
            return queue.isEmpty();
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isClosed() {
        lock.lock();
        try {
            return isClosed;
        } finally {
            lock.unlock();
        }
    }
    
    public void close() {
        lock.lock();
        try {
            isClosed = true;
        } finally {
            lock.unlock();
        }
    }
    
    public boolean isFull() {
        lock.lock();
        try {
            return queue.size() == CAPACITY;
        } finally {
            lock.unlock();
        }
    }
}
