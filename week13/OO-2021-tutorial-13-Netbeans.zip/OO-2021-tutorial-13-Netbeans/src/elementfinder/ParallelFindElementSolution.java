/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementfinder;

/**
 *
 * @author dku
 */
public class ParallelFindElementSolution implements Runnable {
    private final int[] a;
    private final int element;
    private final int lowerBound;
    private final int upperBound;
    private final static int NTHREADS = 5;
    
    public ParallelFindElementSolution(int[] a, int element, int lowerBound, int upperBound) {
        this.a = a;
        this.element = element;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
    }
    
    @Override
    public void run() {
        for (int i = lowerBound; i < upperBound; i += 1) {
            if (a[i] == element) {
                System.out.println(a[i] + " found at index " + i);
                break;
            }
        }
    }
    
    public static void find(int[] a, int element) {
        int chunkSize = a.length / NTHREADS; // Make sure that NTHREADS divides a.length
        for (int i = 0; i < NTHREADS; i += 1) {
            Thread thread = new Thread(new ParallelFindElementSolution(a, element, i * chunkSize, (i + 1) * chunkSize)); 
            thread.start();
        }
    }
}
