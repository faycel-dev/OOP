/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementfinder;

/**
 *
 * @author dku
 */
public class FindElement {
    public static void find (int[] a, int element) {
        for (int i = 0; i < a.length; i += 1) {
            if (a[i] == element) {
                System.out.println(a[i] + " found at index " + i);
                break;
            }
        }
    }
}
