/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elementfinder;

/**
 *
 * @author dku
 */
public class Main {
    private static final int L = 10_000_000;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int [] a1 = new int[L];
      int [] a2 = new int[L];
      for (int i = 0; i < L; i += 1) {
        a1[i] = a2[i] = (int) (Math.random() * L);
      }
      
      a1[5947197] = L;
      a2[5947197] = L;

      FindElement.find(a1, L);
      ParallelFindElementSolution.find(a2, L);
    }
}


