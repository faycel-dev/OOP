/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package max;

/**
 *
 * @author dku
 */
public class Main {
    
    private static final int L = 100_000_000;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      long time1, time2;
      int [] a1 = new int[L];
      int [] a2 = new int[L];
      for (int i = 0; i < L; i += 1) {
        a1[i] = a2[i] = (int) (Math.random() * L);
      }
      System.out.print("sequential max: ");
      time1 = System.currentTimeMillis();
      int max = Max.computeMax(a1, 0, a1.length);
      time2 = System.currentTimeMillis();
      System.out.println((time2 - time1) + " millis. Computed max = " + max);
      
      System.out.print("parrallel max: ");
      time1 = System.currentTimeMillis();
      max = ParallelMaxSolution.computeMax(a2);
      time2 = System.currentTimeMillis();
      System.out.println((time2 - time1) + " millis. Computed max = " + max);

      System.out.println("The number of processors is " + Runtime.getRuntime().availableProcessors());
    }
}
