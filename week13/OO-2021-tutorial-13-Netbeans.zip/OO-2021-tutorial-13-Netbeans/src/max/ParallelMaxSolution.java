/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package max;


/**
 *
 * @author dku
 */
public class ParallelMaxSolution implements Runnable {    
    private final int[] a;
    private final int lowerBound;
    private final int upperBound;
    private final int numberOfThreads;
    private int max;
    
    public ParallelMaxSolution(int[] a, int lowerBound, int upperBound, int numberOfThreads) {
        this.a = a;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        max = Integer.MIN_VALUE;
        this.numberOfThreads = numberOfThreads;
    }
    
    @Override
    public void run() {
        if (numberOfThreads <= 1) {
            max = Max.computeMax(a, lowerBound, upperBound);
        } else {
            int mid = (int) ((long) lowerBound + (long) upperBound) / 2;
            ParallelMaxSolution task1 = new ParallelMaxSolution(a, lowerBound, mid, numberOfThreads / 2);
            ParallelMaxSolution task2 = new ParallelMaxSolution(a, mid, upperBound, numberOfThreads / 2);
            //Thread t1 = new Thread(task1);
            Thread t2 = new Thread(task2);
            //t1.start();
            t2.start();
            
            task1.run();
            
            try {
                //t1.join();
                t2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            max = Math.max(task1.getMax(), task2.getMax());
        }
    }
    
    public int getMax() {
        return max;
    }
    
    public static int computeMax(int[] a) {
        ParallelMaxSolution task = new ParallelMaxSolution(a, 0, a.length, 4);
        task.run();
        
        return task.getMax();
    }
}
